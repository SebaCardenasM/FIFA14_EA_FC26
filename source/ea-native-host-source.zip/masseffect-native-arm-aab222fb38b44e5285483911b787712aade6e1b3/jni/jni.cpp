/* Incomplete, and not 100% accurate C implementation of JNI */
/* See included classes to understand how to interface with this */
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <iterator>
#include <algorithm>
#include <vector>

#include "platform.h"
#include "jni.h"
#include "jni_internals.h"
#include "classes/bytebuffer.h"

extern const JNIInvokeInterface jvm_funcs;
extern const JNINativeInterface jnienv_funcs;
static JavaVM *jvm_global = NULL;

template <typename T> ABI_ATTR static T iface_CallNonVirtualMethodV(JNIEnv *env, jobject obj, jclass jclazz, jmethodID meth, va_list va);
template <typename T> ABI_ATTR static T iface_CallNonVirtualMethodA(JNIEnv *env, jobject obj, jclass jclazz, jmethodID meth, const jvalue *val);

ABI_ATTR static jobjectArray iface_NewObjectArray(JNIEnv *env, jsize len, jclass clz, jobject init)
{
    Class *clazz = (Class*)clz;
    Object *first_elem = (Object*)init;

    if (clazz->instance_size == 0)
        return NULL;

    ArrayObject *arr = (ArrayObject*)calloc(1, sizeof(ArrayObject));
    if (arr == NULL)
        return NULL;

    arr->instance_clazz = clazz;
    arr->count = len;
    arr->element_size = clazz->instance_size;
    arr->elements = (Object*)malloc(clazz->instance_size * len);

    if (arr->elements == NULL) {
        free(arr);
        return NULL;
    }

    if (first_elem) {
        for (jsize i = 0; i < len; i++) {
            uintptr_t offs = (uintptr_t)arr->elements + (arr->element_size * i);
            memcpy((void*)offs, first_elem, arr->element_size);
        }
    } else {
        memset(arr->elements, 0, clazz->instance_size * len);
    }

    return (jobjectArray)arr;
}

ABI_ATTR static jint iface_GetVersion(JNIEnv *env)
{
    return JNI_VERSION_1_6;
}

ABI_ATTR static jclass iface_DefineClass(JNIEnv *env, const char *name, jobject loader,
    const jbyte* buf, jsize bufLen)
{
    WARN_STUB;
    return NULL;
}

ABI_ATTR static jclass iface_FindClass(JNIEnv *env, const char* name)
{
    auto registry = ClassRegistry::get_class_registry();
    auto it = std::find_if(registry.begin(), registry.end(),
        [&](auto *item) { return strcmp(name, item->classpath) == 0; });
    if (it == registry.end()) {
        /*
         * Say so. A missing class used to return NULL in silence, and the cost
         * of that silence is specific: GetStaticMethodID guards its own warning
         * on a non-NULL class, so it then also returns NULL without a word, and
         * the engine calls straight through it. What reaches the log is a
         * SIGSEGV with pc = 0 and a link register pointing into this loader -
         * which reads like a bug in our code, and took a disassembly session to
         * trace back to a class nobody had registered. One line here is the
         * difference between that and an obvious answer.
         */
        warning("FindClass: no fake class registered for '%s' - every method "
                "the game looks up on it will come back NULL.\n", name);
        return NULL;
    }

    return (jclass)*it;
}

ABI_ATTR static jclass iface_GetSuperclass(JNIEnv *env, jclass jclazz)
{
    /* No inheritance here */
    return jclazz;
}

ABI_ATTR static jboolean iface_IsAssignableFrom(JNIEnv *env, jclass jclazz1, jclass jclazz2)
{
    WARN_STUB;
    return JNI_FALSE;
}

ABI_ATTR static jmethodID iface_FromReflectedMethod(JNIEnv *env, jobject jmethod)
{
    WARN_STUB;
    return NULL;
}

ABI_ATTR static jfieldID iface_FromReflectedField(JNIEnv *env, jobject jfield)
{
    WARN_STUB;
    return NULL;
}

ABI_ATTR static jobject iface_ToReflectedMethod(JNIEnv *env, jclass jcls, jmethodID methodID, jboolean isStatic)
{
    WARN_STUB;
    return NULL;
}

ABI_ATTR static jobject iface_ToReflectedField(JNIEnv *env, jclass jcls, jfieldID fieldID, jboolean isStatic)
{
    WARN_STUB;
    return NULL;
}

ABI_ATTR static jint iface_Throw(JNIEnv *env, jthrowable jobj)
{
    WARN_STUB;
    return 0;
}

ABI_ATTR static jint iface_ThrowNew(JNIEnv *env, jclass jclazz, const char* message)
{
    WARN_STUB;
    return 0;
}

ABI_ATTR static jthrowable iface_ExceptionOccurred(JNIEnv *env)
{
    WARN_STUB;
    return NULL;
}

ABI_ATTR static void iface_ExceptionDescribe(JNIEnv *env)
{
    WARN_STUB;
}

ABI_ATTR static void iface_ExceptionClear(JNIEnv *env)
{
    WARN_STUB;
}

ABI_ATTR static void iface_FatalError(JNIEnv *env, const char* msg)
{
    WARN_STUB;
}

ABI_ATTR static jint iface_PushLocalFrame(JNIEnv *env, jint capacity)
{
    WARN_STUB;
    return 0;
}

ABI_ATTR static jobject iface_PopLocalFrame(JNIEnv *env, jobject jresult)
{
    WARN_STUB;
    return NULL;
}

ABI_ATTR static jobject iface_NewGlobalRef(JNIEnv *env, jobject jobj)
{
    return jobj;
}

ABI_ATTR static void iface_DeleteGlobalRef(JNIEnv *env, jobject jglobalRef)
{
    ;
}

ABI_ATTR static jobject iface_NewLocalRef(JNIEnv *env, jobject jobj)
{
    return jobj;
}

ABI_ATTR static void iface_DeleteLocalRef(JNIEnv *env, jobject jlocalRef)
{
    ;
}

ABI_ATTR static jint iface_EnsureLocalCapacity(JNIEnv *env, jint capacity)
{
    WARN_STUB;
    return 0;
}

ABI_ATTR static jboolean iface_IsSameObject(JNIEnv *env, jobject jref1, jobject jref2)
{
    return jref1 == jref2;
}

ABI_ATTR static jobject iface_AllocObject(JNIEnv *env, jclass jclazz)
{
    WARN_STUB;
    return NULL;
}

ABI_ATTR static jobject iface_NewObject(JNIEnv *env, jclass jclazz, jmethodID methodID, ...)
{
    Class *clazz = (Class*)jclazz;
    if (clazz->instance_size == 0)
        return NULL;
 
    jobject obj = (jobject)calloc(1, clazz->instance_size);
    va_list va;
    va_start(va, methodID);
    iface_CallNonVirtualMethodV<void>(env, obj, jclazz, methodID, va);
    va_end(va);
    return obj;
}

ABI_ATTR static jobject iface_NewObjectV(JNIEnv *env, jclass jclazz, jmethodID methodID, va_list args)
{
    Class *clazz = (Class*)jclazz;
    if (clazz == NULL)
        return NULL;

    if (clazz->instance_size == 0)
        return NULL;

    jobject obj = (jobject)calloc(1, clazz->instance_size);
    iface_CallNonVirtualMethodV<void>(env, obj, jclazz, methodID, args);
    return obj;
}

ABI_ATTR static jobject iface_NewObjectA(JNIEnv *env, jclass jclazz, jmethodID methodID, const jvalue* args)
{
    Class *clazz = (Class*)jclazz;
    if (clazz->instance_size == 0)
        return NULL;

    jobject obj = (jobject)calloc(1, clazz->instance_size);
    iface_CallNonVirtualMethodA<void>(env, obj, jclazz, methodID, args);
    return obj;
}

ABI_ATTR static jclass iface_GetObjectClass(JNIEnv *env, jobject jobj)
{
    Object *obj = (Object*)jobj;
    if (obj == NULL)
        return NULL;

    return (jclass)obj->_getClass();
}

ABI_ATTR static jboolean iface_IsInstanceOf(JNIEnv *env, jobject jobj, jclass jclazz)
{
    if (jobj == NULL) {
        fatal_error("IsInstanceOf: NULL object dereference, returning FALSE.\n");
        return JNI_FALSE;
    }

    if (jclazz == NULL)
        return JNI_FALSE;

    Object *obj = (Object *)jobj;
    return (jclass)obj->_getClass() == jclazz;
}

static ManagedMethod *GetMethodIDGeneric(const char *func, JNIEnv *env, Class *clz, const char* name, const char* sig)
{
    if (clz == NULL) {
        /*
         * Print the signature, not just the name.
         *
         * Method lookup below is an exact strcmp on both, so a fake class
         * written with a plausible-looking signature simply never matches and
         * the engine gets NULL exactly as if the class were still missing -
         * with no new evidence in the log to say which of the two it was.
         * Echoing the descriptor the game asked for turns writing the next
         * class from guesswork into transcription.
         */
        fatal_error("%s: NULL class dereference, returning NULL "
                    "(was looking for '%s%s').\n", func, name, sig ? sig : "");
        return NULL;
    }

    /* Local divergence from gmloader-next: a class with no method table at all
     * is legal - most of the registered classes are pure data holders - and it
     * has to answer "no such method" instead of walking a null array. The game
     * hits this the first time it calls GetMethodID on the activity object. */
    if (clz->managed_methods == NULL)
        return NULL;

    for (int i = 0; clz->managed_methods[i].name; i++) {
        if ((strcmp(name, clz->managed_methods[i].name)      == 0) &&
            (strcmp(sig,  clz->managed_methods[i].signature) == 0)) {
            return (ManagedMethod*)&clz->managed_methods[i];
        }
    }

    return NULL;
}

static jfieldID GetFieldIdGeneric(const char *func, JNIEnv *env, Class *clz, const char* name, const char* sig)
{
    if (clz == NULL) {
        fatal_error("%s: NULL class dereference, returning NULL.\n", func);
        return NULL;
    }

    /* Same divergence, same reason. */
    if (clz->fields == NULL)
        return NULL;

    for (int i = 0; clz->fields[i].name; i++) {
        if (strcmp(name, clz->fields[i].name) == 0) {
            return (jfieldID)&clz->fields[i];
        }
    }
   
    return NULL;
}

ABI_ATTR static jmethodID iface_GetMethodID(JNIEnv *env, jclass clazz, const char* name, const char* sig)
{
    Class *clz = (Class*)clazz;
    ManagedMethod *method = GetMethodIDGeneric("GetMethodID", env, clz, name, sig);
    if (method && method->is_static_method == false) {
        return (jmethodID)method;
    }

    if (clz)
        warning("Class %s does not have method %s%s.\n", clz->classname, name, sig);

    return NULL;
}

ABI_ATTR static jfieldID iface_GetFieldID(JNIEnv *env, jclass clazz, const char* name, const char* sig)
{
    Class *clz = (Class*)clazz;
    FieldId *field = (FieldId*)GetFieldIdGeneric("GetFieldID", env, clz, name, sig);
    if (field && (field->is_static == false))
        return (jfieldID)field;
    
    if (clz)
        warning("Class %s does not have field %s (%s).\n", clz->classname, name, sig);

    return NULL;
}

ABI_ATTR static jmethodID iface_GetStaticMethodID(JNIEnv *env, jclass clazz, const char* name, const char* sig)
{
    Class *clz = (Class*)clazz;
    ManagedMethod *method = GetMethodIDGeneric("GetStaticMethodID", env, clz, name, sig);
    if (method && method->is_static_method == true) {
        return (jmethodID)method;
    }

    if (clz)
        warning("Class %s does not have static method %s%s.\n", clz->classname, name, sig);

    return NULL;
}

ABI_ATTR static jfieldID iface_GetStaticFieldID(JNIEnv *env, jclass clazz, const char* name, const char* sig)
{
    Class *clz = (Class*)clazz;
    FieldId *field = (FieldId*)GetFieldIdGeneric("GetStaticFieldID", env, clz, name, sig);
    if (field && (field->is_static == true))
        return (jfieldID)field;
    
    if (clz)
        warning("Class %s does not have static field %s.\n", clz->classname, name, sig);

    return NULL;
}

static uint32_t decode_utf8(const unsigned char **cursor)
{
    const unsigned char *p = *cursor;
    uint32_t value;
    size_t continuation;

    if (*p < 0x80) {
        *cursor = p + 1;
        return *p;
    }
    if ((*p & 0xe0) == 0xc0) {
        value = *p & 0x1f;
        continuation = 1;
    } else if ((*p & 0xf0) == 0xe0) {
        value = *p & 0x0f;
        continuation = 2;
    } else if ((*p & 0xf8) == 0xf0) {
        value = *p & 0x07;
        continuation = 3;
    } else {
        *cursor = p + 1;
        return 0xfffd;
    }

    p++;
    for (size_t i = 0; i < continuation; i++) {
        if ((p[i] & 0xc0) != 0x80) {
            *cursor = p;
            return 0xfffd;
        }
        value = (value << 6) | (p[i] & 0x3f);
    }
    *cursor = p + continuation;

    const uint32_t minimum[] = {0, 0x80, 0x800, 0x10000};
    if (value < minimum[continuation] || value > 0x10ffff ||
        (value >= 0xd800 && value <= 0xdfff))
        return 0xfffd;
    return value;
}

static std::vector<jchar> utf8_to_utf16(const char *text)
{
    std::vector<jchar> result;
    if (!text)
        return result;

    const unsigned char *cursor = (const unsigned char *)text;
    while (*cursor) {
        uint32_t value = decode_utf8(&cursor);
        if (value <= 0xffff) {
            result.push_back((jchar)value);
        } else {
            value -= 0x10000;
            result.push_back((jchar)(0xd800 + (value >> 10)));
            result.push_back((jchar)(0xdc00 + (value & 0x3ff)));
        }
    }
    return result;
}

static void append_utf8(std::vector<char> &result, uint32_t value)
{
    if (value <= 0x7f) {
        result.push_back((char)value);
    } else if (value <= 0x7ff) {
        result.push_back((char)(0xc0 | (value >> 6)));
        result.push_back((char)(0x80 | (value & 0x3f)));
    } else if (value <= 0xffff) {
        result.push_back((char)(0xe0 | (value >> 12)));
        result.push_back((char)(0x80 | ((value >> 6) & 0x3f)));
        result.push_back((char)(0x80 | (value & 0x3f)));
    } else {
        result.push_back((char)(0xf0 | (value >> 18)));
        result.push_back((char)(0x80 | ((value >> 12) & 0x3f)));
        result.push_back((char)(0x80 | ((value >> 6) & 0x3f)));
        result.push_back((char)(0x80 | (value & 0x3f)));
    }
}

static std::vector<char> utf16_to_utf8(const jchar *text, jsize length)
{
    std::vector<char> result;
    for (jsize i = 0; text && i < length; i++) {
        uint32_t value = text[i];
        if (value >= 0xd800 && value <= 0xdbff &&
            i + 1 < length &&
            text[i + 1] >= 0xdc00 && text[i + 1] <= 0xdfff) {
            value = 0x10000 +
                ((value - 0xd800) << 10) +
                (text[++i] - 0xdc00);
        } else if (value >= 0xd800 && value <= 0xdfff) {
            value = 0xfffd;
        }
        append_utf8(result, value);
    }
    result.push_back('\0');
    return result;
}

ABI_ATTR static jstring iface_NewString(JNIEnv *env, const jchar* unicodeChars, jsize len)
{
    std::vector<char> utf8 = utf16_to_utf8(unicodeChars, len);
    String *str = new String((const char *)utf8.data());
    return (jstring)str;
}

ABI_ATTR static jsize iface_GetStringLength(JNIEnv *env, jstring jstr)
{
    String *str = (String*)jstr;
    return str && str->str
        ? (jsize)utf8_to_utf16(str->str).size()
        : 0;
}

ABI_ATTR static const jchar* iface_GetStringChars(JNIEnv *env, jstring jstr, jboolean* isCopy)
{
    String *str = (String*)jstr;
    if (isCopy)
        *isCopy = JNI_TRUE;

    if (!str || !str->str)
        return NULL;

    std::vector<jchar> utf16 = utf8_to_utf16(str->str);
    jchar *copy = (jchar *)calloc(utf16.size() + 1, sizeof(jchar));
    if (!copy)
        return NULL;
    std::copy(utf16.begin(), utf16.end(), copy);
    return copy;
}

ABI_ATTR static void iface_ReleaseStringChars(JNIEnv *env, jstring jstr, const jchar* chars)
{
    free((void*)chars);
}

ABI_ATTR static jstring iface_NewStringUTF(JNIEnv *env, const char* bytes)
{
    String *str = new String(bytes);
    return (jstring)str;
}

ABI_ATTR static jsize iface_GetStringUTFLength(JNIEnv *env, jstring jstr)
{
    String *str = (String*)jstr;
    return strlen(str->str);
}

ABI_ATTR static const char* iface_GetStringUTFChars(JNIEnv *env, jstring jstr, jboolean* isCopy)
{
    String *str = (String*)jstr;
    if (isCopy)
        *isCopy = JNI_TRUE;

    return strdup(jstr ? str->str : "(nil)");
}

ABI_ATTR static void iface_ReleaseStringUTFChars(JNIEnv *env, jstring jstr, const char* utf)
{
    free((void*)utf);
}

ABI_ATTR static jsize iface_GetArrayLength(JNIEnv *env, jarray jarr)
{
    ArrayObject* arr = (ArrayObject*)jarr;
    return arr->count;
}

ABI_ATTR static jobject iface_GetObjectArrayElement(JNIEnv *env, jobjectArray jarr, jsize index)
{
    ArrayObject* arr = (ArrayObject*)jarr;
    uintptr_t offs = (uintptr_t)arr->elements + (index * arr->element_size);
    return (jobject)(offs);
}

ABI_ATTR static void iface_SetObjectArrayElement(JNIEnv *env, jobjectArray jarr, jsize index, jobject jobj)
{
    ArrayObject* arr = (ArrayObject*)jarr;
    if (jarr == NULL)
        return;

    uintptr_t offs = (intptr_t)arr->elements + (arr->element_size * index);
    memcpy((void*)offs, (void*)jobj, arr->element_size);
}

ABI_ATTR static jint iface_RegisterNatives(JNIEnv *env, jclass jclazz,
    const JNINativeMethod* methods, jint nMethods)
{
    WARN_STUB;
    return 0;
}

ABI_ATTR static jint iface_UnregisterNatives(JNIEnv *env, jclass jclazz)
{
    WARN_STUB;
    return 0;
}

ABI_ATTR static jint iface_MonitorEnter(JNIEnv *env, jobject jobj)
{
    WARN_STUB;
    return 0;
}

ABI_ATTR static jint iface_MonitorExit(JNIEnv *env, jobject jobj)
{
    WARN_STUB;
    return 0;
}

ABI_ATTR static jint iface_GetJavaVM(JNIEnv *env, JavaVM** vm)
{
    *vm = jvm_global;
    return 0;
}

ABI_ATTR static void iface_GetStringRegion(JNIEnv *env, jstring jstr, jsize start, jsize len, jchar* buf)
{
    WARN_STUB;
}

ABI_ATTR static void iface_GetStringUTFRegion(JNIEnv *env, jstring jstr, jsize start, jsize len, char* buf)
{
    WARN_STUB;
}

ABI_ATTR static void* iface_GetPrimitiveArrayCritical(JNIEnv *env, jarray jarr, jboolean* isCopy)
{
    ArrayObject *array = (ArrayObject*)jarr;
    if (jarr == NULL)
        return NULL;

    // We always return direct references
    if (isCopy)
        *isCopy = false;
    
    return array->elements;
}

ABI_ATTR static void iface_ReleasePrimitiveArrayCritical(JNIEnv *env, jarray jarr, void* carray, jint mode)
{
    // We always return direct references.
    if (mode == JNI_COMMIT) {
        warning("ReleasePrimitiveArrayCritical with unimplemented mode. Fix GetPrimitiveArrayCritical");
    }
}

ABI_ATTR static const jchar* iface_GetStringCritical(JNIEnv *env, jstring jstr, jboolean* isCopy)
{
    WARN_STUB;
    return NULL;
}

ABI_ATTR static void iface_ReleaseStringCritical(JNIEnv *env, jstring jstr, const jchar* carray)
{
    WARN_STUB;
}

ABI_ATTR static jweak iface_NewWeakGlobalRef(JNIEnv *env, jobject jobj)
{
    WARN_STUB;
    return NULL;
}

ABI_ATTR static void iface_DeleteWeakGlobalRef(JNIEnv *env, jweak wref)
{
    WARN_STUB;
}

ABI_ATTR static jboolean iface_ExceptionCheck(JNIEnv *env)
{
    WARN_STUB;
    return JNI_FALSE;
}

ABI_ATTR static jobjectRefType iface_GetObjectRefType(JNIEnv *env, jobject jobj)
{
    WARN_STUB;
    return JNIInvalidRefType;
}

ABI_ATTR static jobject iface_NewDirectByteBuffer(JNIEnv *env, void* address, jlong capacity)
{
    ByteBuffer *buf = new ByteBuffer(address, capacity);
    return (jobject)buf;
}

ABI_ATTR static void* iface_GetDirectBufferAddress(JNIEnv *env, jobject jbuf)
{
    return ((ByteBuffer*)jbuf)->address();
}

ABI_ATTR static jlong iface_GetDirectBufferCapacity(JNIEnv *env, jobject jbuf)
{
    return ((ByteBuffer*)jbuf)->capacity();
}

template <typename T>
ABI_ATTR static T iface_CallMethod(JNIEnv *env, jobject obj, jmethodID meth, ...)
{
    ManagedMethod *method = (ManagedMethod*)meth;
    if (!method || !method->addr_variadic) {
        if constexpr (std::is_same_v<T, void>)
            return;
        else
            return (T)0;
    }

#ifdef WANTS_TRACE
    printf("TRACE JNI: %s...\n", method->name);
#endif

    va_list va;
    va_start(va, meth);
    /*
     * Two dispatcher shapes reach here and only the method knows which it is.
     * RegisterNonVirtual builds (env, obj, jclass, va_list); Register builds
     * (env, obj, va_list). Calling the four-argument one with three arguments
     * reads a register that was never set and uses it as the va_list, which
     * surfaces as garbage arguments and a fault deep inside the method - see
     * AudioTrack.write(short[]).
     */
    if (method->takes_class) {
        T (*dispatch4)(JNIEnv *, jobject, jclass, va_list) =
            (decltype(dispatch4))method->addr_variadic;
        if constexpr (std::is_same_v<T, void>) {
            dispatch4(env, obj, (jclass)method->clazz, va);
            va_end(va);
            return;
        } else {
            T ret = dispatch4(env, obj, (jclass)method->clazz, va);
            va_end(va);
            return ret;
        }
    }

    T (*dispatch)(JNIEnv *, jobject, va_list) = (decltype(dispatch))method->addr_variadic;
    if constexpr (std::is_same_v<T, void>) {
        dispatch(env, obj, va);
        va_end(va);
    } else {
        T ret = dispatch(env, obj, va);
        va_end(va);
        return ret;
    }
}

template <typename T>
ABI_ATTR static T iface_CallMethodV(JNIEnv *env, jobject obj, jmethodID meth, va_list va)
{
    ManagedMethod *method = (ManagedMethod*)meth;
    if (!method || !method->addr_variadic) {
        if constexpr (std::is_same_v<T, void>)
            return;
        else
            return (T)0;
    }

#ifdef WANTS_TRACE
    printf("TRACE JNI: %s...\n", method->name);
#endif

    /* Same two shapes as iface_CallMethod above; see the comment there. */
    if (method->takes_class) {
        T (*dispatch4)(JNIEnv *, jobject, jclass, va_list) =
            (decltype(dispatch4))method->addr_variadic;
        if constexpr (std::is_same_v<T, void>) {
            dispatch4(env, obj, (jclass)method->clazz, va);
            return;
        } else {
            return dispatch4(env, obj, (jclass)method->clazz, va);
        }
    }

    T (*dispatch)(JNIEnv *, jobject, va_list) = (decltype(dispatch))method->addr_variadic;
    if constexpr (std::is_same_v<T, void>) {
        dispatch(env, obj, va);
    } else {
        T ret = dispatch(env, obj, va);
        return ret;
    }
}

template <typename T> 
ABI_ATTR static T iface_CallMethodA(JNIEnv *env, jobject obj, jmethodID meth, const jvalue *val)
{
    ManagedMethod *method = (ManagedMethod*)meth;
    if (!method || !method->addr_array) {
        if constexpr (std::is_same_v<T, void>)
            return;
        else
            return (T)0;
    }

#ifdef WANTS_TRACE
    printf("TRACE JNI: %s...\n", method->name);
#endif

    T (*dispatch)(JNIEnv *, jobject, const jvalue *) = (decltype(dispatch))method->addr_array;
    if constexpr (std::is_same_v<T, void>) {
        dispatch(env, obj, val);
    } else {
        return dispatch(env, obj, val);
    }
}

template <typename T>
ABI_ATTR static T iface_CallStaticMethod(JNIEnv *env, jclass jclz, jmethodID meth, ...)
{
    ManagedMethod *method = (ManagedMethod*)meth;
    if (!method || !method->addr_variadic) {
        if constexpr (std::is_same_v<T, void>)
            return;
        else
            return (T)0;
    }

#ifdef WANTS_TRACE
    printf("TRACE JNI: %s...\n", method->name);
#endif

    va_list va;
    va_start(va, meth);
    T (*dispatch)(JNIEnv *, jclass, va_list) = (decltype(dispatch))method->addr_variadic;
    if constexpr (std::is_same_v<T, void>) {
        dispatch(env, jclz, va);
        va_end(va);
    } else {
        T ret = dispatch(env, jclz, va);
        va_end(va);
        return ret;
    }
}

template <typename T>
ABI_ATTR static T iface_CallStaticMethodV(JNIEnv *env, jclass jclz, jmethodID meth, va_list va)
{
    ManagedMethod *method = (ManagedMethod*)meth;
    if (!method || !method->addr_variadic) {
        if constexpr (std::is_same_v<T, void>)
            return;
        else
            return (T)0;
    }

#ifdef WANTS_TRACE
    printf("TRACE JNI: %s...\n", method->name);
#endif

    T (*dispatch)(JNIEnv *, jclass, va_list) = (decltype(dispatch))method->addr_variadic;
    if constexpr (std::is_same_v<T, void>) {
        dispatch(env, jclz, va);
    } else {
        T ret = dispatch(env, jclz, va);
        return ret;
    }
}

template <typename T> 
ABI_ATTR static T iface_CallStaticMethodA(JNIEnv *env, jclass clz, jmethodID meth, const jvalue *val)
{
    ManagedMethod *method = (ManagedMethod*)meth;
    if (!method || !method->addr_array) {
        if constexpr (std::is_same_v<T, void>)
            return;
        else
            return (T)0;
    }

#ifdef WANTS_TRACE
    printf("TRACE JNI: %s...\n", method->name);
#endif

    T (*dispatch)(JNIEnv *, jclass, const jvalue *) = (decltype(dispatch))method->addr_array;
    if constexpr (std::is_same_v<T, void>) {
        dispatch(env, clz, val);
    } else {
        return dispatch(env, clz, val);
    }
}

template <typename T>
ABI_ATTR static T iface_CallNonVirtualMethod(JNIEnv *env, jobject obj, jclass jclazz, jmethodID meth, ...)
{
    ManagedMethod *method = (ManagedMethod*)meth;
    if (!method || !method->addr_variadic) {
        if constexpr (std::is_same_v<T, void>)
            return;
        else
            return (T)0;
    }

#ifdef WANTS_TRACE
    printf("TRACE JNI: %s...\n", method->name);
#endif

    va_list va;
    va_start(va, meth);
    T (*dispatch)(JNIEnv *, jobject, jclass, va_list) = (decltype(dispatch))method->addr_variadic;
    if constexpr (std::is_same_v<T, void>) {
        dispatch(env, obj, jclazz, va);
        va_end(va);
    } else {
        T ret = dispatch(env, obj, jclazz, va);
        va_end(va);
        return ret;
    }
}

template <typename T>
ABI_ATTR static T iface_CallNonVirtualMethodV(JNIEnv *env, jobject obj, jclass jclazz, jmethodID meth, va_list va)
{
    ManagedMethod *method = (ManagedMethod*)meth;
    if (!method || !method->addr_variadic) {
        if constexpr (std::is_same_v<T, void>)
            return;
        else
            return (T)0;
    }

#ifdef WANTS_TRACE
    printf("TRACE JNI: %s...\n", method->name);
#endif

    T (*dispatch)(JNIEnv *, jobject, jclass, va_list) = (decltype(dispatch))method->addr_variadic;
    if constexpr (std::is_same_v<T, void>) {
        dispatch(env, obj, jclazz, va);
    } else {
        return dispatch(env, obj, jclazz, va);
    }
}

template <typename T> 
ABI_ATTR static T iface_CallNonVirtualMethodA(JNIEnv *env, jobject obj, jclass jclazz, jmethodID meth, const jvalue *val)
{
    ManagedMethod *method = (ManagedMethod*)meth;
    if (!method || !method->addr_variadic) {
        if constexpr (std::is_same_v<T, void>)
            return;
        else
            return (T)0;
    }

#ifdef WANTS_TRACE
    printf("TRACE JNI: %s...\n", method->name);
#endif

    T (*dispatch)(JNIEnv *, jobject, jclass, const jvalue *) = (decltype(dispatch))method->addr_array;
    if constexpr (std::is_same_v<T, void>) {
        dispatch(env, obj, jclazz, val);
    } else {
        return dispatch(env, obj, jclazz, val);
    }
}

template <typename T>
ABI_ATTR static T iface_GetField(JNIEnv *env, jobject obj, jfieldID fieldID)
{
    FieldId *f = (FieldId*)fieldID;
    if (f == NULL || f->is_static == 1 || obj == NULL)
        return (T)0;

    T *offs = (T*)((intptr_t)obj + f->offset);

    return *offs;
}

template <typename T>
ABI_ATTR static void iface_SetField(JNIEnv *env, jobject obj, jfieldID fieldID, T value)
{
    FieldId *f = (FieldId*)fieldID;
    if (f == NULL || f->is_static == 1 || obj == NULL)
        return;

    T *offs = (T*)((intptr_t)obj + f->offset);

    *offs = value;
}

template <typename T>
ABI_ATTR static T iface_GetStaticField(JNIEnv *env, jclass clz, jfieldID fieldID)
{
    FieldId *f = (FieldId*)fieldID;
    if (f == NULL || f->is_static == 0 || clz == NULL)
        return (T)0;

    T offs = (T)(f->offset);
    return offs;
}

template <typename T>
ABI_ATTR static void iface_SetStaticField(JNIEnv *env, jclass clz, jfieldID fieldID, T value)
{
    FieldId *f = (FieldId*)fieldID;
    if (f == NULL || f->is_static == 0 || clz == NULL)
        return;

    T *offs = (T*)f->offset;
    *offs = value;
}

template <typename T>
ABI_ATTR static T iface_NewArray(JNIEnv *env, jsize length)
{
    jsize t = 4;
    if constexpr (std::is_same_v<T, jbooleanArray>) t = sizeof(jboolean);
    if constexpr (std::is_same_v<T, jbyteArray>) t = sizeof(jbyte);
    if constexpr (std::is_same_v<T, jcharArray>) t = sizeof(jchar);
    if constexpr (std::is_same_v<T, jshortArray>) t = sizeof(jshort);
    if constexpr (std::is_same_v<T, jintArray>) t = sizeof(jint);
    if constexpr (std::is_same_v<T, jlongArray>) t = sizeof(jlong);
    if constexpr (std::is_same_v<T, jfloatArray>) t = sizeof(jfloat);
    if constexpr (std::is_same_v<T, jdoubleArray>) t = sizeof(jdouble);

    ArrayObject *array = (ArrayObject *)calloc(1, sizeof(ArrayObject)); 
    array->count = length;
    array->element_size = t;
    array->elements = calloc(length, t);

    return (T)array;
}

template <typename T, typename Tarr>
ABI_ATTR static T * iface_GetArrayElements(JNIEnv *env, Tarr arr, jboolean *isCopy)
{
    ArrayObject *array = (ArrayObject*)arr;
    if (array == NULL)
        return NULL;

    if (isCopy)
        *isCopy = JNI_TRUE;
    
    T *elements = (T*)malloc(array->count * array->element_size);
    memcpy((void*)elements, array->elements, array->count * array->element_size);
    return elements;
}

template <typename T, typename Tarr>
ABI_ATTR static void iface_ReleaseArrayElements(JNIEnv*, Tarr arr, T *els, jint mode)
{
    ArrayObject *array = (ArrayObject*)arr;
    if (array == NULL)
        return;

    if (mode != JNI_ABORT)
        memcpy(array->elements, els, array->count * array->element_size);
    
    if (mode != JNI_COMMIT)
        free(els);
}

template <typename T, typename Tarr>
ABI_ATTR static void iface_GetArrayRegion(JNIEnv *env, Tarr arr, jsize start, jsize len, T *buf)
{
    ArrayObject *array = (ArrayObject*)arr;
    if (array == NULL)
        return;

    if (len > array->count - start)
        return;

    uintptr_t offs = (uintptr_t)array->elements + (start * array->element_size);
    memcpy(buf, (void*)offs, len * array->element_size);
}

template <typename T, typename Tarr>
ABI_ATTR void iface_SetArrayRegion(JNIEnv *env, Tarr arr, jsize start, jsize len, const T *buf)
{
    ArrayObject *array = (ArrayObject*)arr;
    if (array == NULL)
        return;

    if (len > array->count - start)
        return;

    uintptr_t offs = (uintptr_t)array->elements + (start * array->element_size);
    memcpy((void*)offs, (void*)buf, len * array->element_size);
}

const JNINativeInterface jnienv_funcs = {
    .reserved0 = NULL,
    .GetVersion = &iface_GetVersion,
    .DefineClass = &iface_DefineClass,
    .FindClass = &iface_FindClass,

    .FromReflectedMethod = &iface_FromReflectedMethod,
    .FromReflectedField = &iface_FromReflectedField,
    /* spec doesn't show jboolean parameter */
    .ToReflectedMethod = &iface_ToReflectedMethod,
    .GetSuperclass = &iface_GetSuperclass,
    .IsAssignableFrom = &iface_IsAssignableFrom,

    /* spec doesn't show jboolean parameter */
    .ToReflectedField = &iface_ToReflectedField,
    .Throw = &iface_Throw,
    .ThrowNew = &iface_ThrowNew,
    .ExceptionOccurred = &iface_ExceptionOccurred,
    .ExceptionDescribe = &iface_ExceptionDescribe,
    .ExceptionClear = &iface_ExceptionClear,
    .FatalError = &iface_FatalError,
    .PushLocalFrame = &iface_PushLocalFrame,
    .PopLocalFrame = &iface_PopLocalFrame,
    .NewGlobalRef = &iface_NewGlobalRef,
    .DeleteGlobalRef = &iface_DeleteGlobalRef,
    .DeleteLocalRef = &iface_DeleteLocalRef,
    .IsSameObject = &iface_IsSameObject,
    .NewLocalRef = &iface_NewLocalRef,
    .EnsureLocalCapacity = &iface_EnsureLocalCapacity,
    .AllocObject = &iface_AllocObject,
    .NewObject = &iface_NewObject,
    .NewObjectV = &iface_NewObjectV,
    .NewObjectA = &iface_NewObjectA,
    .GetObjectClass = &iface_GetObjectClass,
    .IsInstanceOf = &iface_IsInstanceOf,
    .GetMethodID = &iface_GetMethodID,

    .CallObjectMethod = &iface_CallMethod,
    .CallObjectMethodV = &iface_CallMethodV,
    .CallObjectMethodA = &iface_CallMethodA,
    .CallBooleanMethod = &iface_CallMethod,
    .CallBooleanMethodV = &iface_CallMethodV,
    .CallBooleanMethodA = &iface_CallMethodA,
    .CallByteMethod = &iface_CallMethod,
    .CallByteMethodV = &iface_CallMethodV,
    .CallByteMethodA = &iface_CallMethodA,
    .CallCharMethod = &iface_CallMethod,
    .CallCharMethodV = &iface_CallMethodV,
    .CallCharMethodA = &iface_CallMethodA,
    .CallShortMethod = &iface_CallMethod,
    .CallShortMethodV = &iface_CallMethodV,
    .CallShortMethodA = &iface_CallMethodA,
    .CallIntMethod = &iface_CallMethod,
    .CallIntMethodV = &iface_CallMethodV,
    .CallIntMethodA = &iface_CallMethodA,
    .CallLongMethod = &iface_CallMethod,
    .CallLongMethodV = &iface_CallMethodV,
    .CallLongMethodA = &iface_CallMethodA,
    .CallFloatMethod = &iface_CallMethod,
    .CallFloatMethodV = &iface_CallMethodV,
    .CallFloatMethodA = &iface_CallMethodA,
    .CallDoubleMethod = &iface_CallMethod,
    .CallDoubleMethodV = &iface_CallMethodV,
    .CallDoubleMethodA = &iface_CallMethodA,
    .CallVoidMethod = &iface_CallMethod,
    .CallVoidMethodV = &iface_CallMethodV,
    .CallVoidMethodA = &iface_CallMethodA,
    .CallNonvirtualObjectMethod = &iface_CallNonVirtualMethod,
    .CallNonvirtualObjectMethodV = &iface_CallNonVirtualMethodV,
    .CallNonvirtualObjectMethodA = &iface_CallNonVirtualMethodA,
    .CallNonvirtualBooleanMethod = &iface_CallNonVirtualMethod,
    .CallNonvirtualBooleanMethodV = &iface_CallNonVirtualMethodV,
    .CallNonvirtualBooleanMethodA = &iface_CallNonVirtualMethodA,
    .CallNonvirtualByteMethod = &iface_CallNonVirtualMethod,
    .CallNonvirtualByteMethodV = &iface_CallNonVirtualMethodV,
    .CallNonvirtualByteMethodA = &iface_CallNonVirtualMethodA,
    .CallNonvirtualCharMethod = &iface_CallNonVirtualMethod,
    .CallNonvirtualCharMethodV = &iface_CallNonVirtualMethodV,
    .CallNonvirtualCharMethodA = &iface_CallNonVirtualMethodA,
    .CallNonvirtualShortMethod = &iface_CallNonVirtualMethod,
    .CallNonvirtualShortMethodV = &iface_CallNonVirtualMethodV,
    .CallNonvirtualShortMethodA = &iface_CallNonVirtualMethodA,
    .CallNonvirtualIntMethod = &iface_CallNonVirtualMethod,
    .CallNonvirtualIntMethodV = &iface_CallNonVirtualMethodV,
    .CallNonvirtualIntMethodA = &iface_CallNonVirtualMethodA,
    .CallNonvirtualLongMethod = &iface_CallNonVirtualMethod,
    .CallNonvirtualLongMethodV = &iface_CallNonVirtualMethodV,
    .CallNonvirtualLongMethodA = &iface_CallNonVirtualMethodA,
    .CallNonvirtualFloatMethod = &iface_CallNonVirtualMethod,
    .CallNonvirtualFloatMethodV = &iface_CallNonVirtualMethodV,
    .CallNonvirtualFloatMethodA = &iface_CallNonVirtualMethodA,
    .CallNonvirtualDoubleMethod = &iface_CallNonVirtualMethod,
    .CallNonvirtualDoubleMethodV = &iface_CallNonVirtualMethodV,
    .CallNonvirtualDoubleMethodA = &iface_CallNonVirtualMethodA,
    .CallNonvirtualVoidMethod = &iface_CallNonVirtualMethod,
    .CallNonvirtualVoidMethodV = &iface_CallNonVirtualMethodV,
    .CallNonvirtualVoidMethodA = &iface_CallNonVirtualMethodA,

    .GetFieldID = &iface_GetFieldID,
    .GetObjectField = &iface_GetField,
    .GetBooleanField = &iface_GetField,
    .GetByteField = &iface_GetField,
    .GetCharField = &iface_GetField,
    .GetShortField = &iface_GetField,
    .GetIntField = &iface_GetField,
    .GetLongField = &iface_GetField,
    .GetFloatField = &iface_GetField,
    .GetDoubleField = &iface_GetField,
    .SetObjectField = &iface_SetField,
    .SetBooleanField = &iface_SetField,
    .SetByteField = &iface_SetField,
    .SetCharField = &iface_SetField,
    .SetShortField = &iface_SetField,
    .SetIntField = &iface_SetField,
    .SetLongField = &iface_SetField,
    .SetFloatField = &iface_SetField,
    .SetDoubleField = &iface_SetField,
    .GetStaticMethodID = &iface_GetStaticMethodID,
    .CallStaticObjectMethod = &iface_CallStaticMethod,
    .CallStaticObjectMethodV = &iface_CallStaticMethodV,
    .CallStaticObjectMethodA = &iface_CallStaticMethodA,
    .CallStaticBooleanMethod = &iface_CallStaticMethod,
    .CallStaticBooleanMethodV = &iface_CallStaticMethodV,
    .CallStaticBooleanMethodA = &iface_CallStaticMethodA,
    .CallStaticByteMethod = &iface_CallStaticMethod,
    .CallStaticByteMethodV = &iface_CallStaticMethodV,
    .CallStaticByteMethodA = &iface_CallStaticMethodA,
    .CallStaticCharMethod = &iface_CallStaticMethod,
    .CallStaticCharMethodV = &iface_CallStaticMethodV,
    .CallStaticCharMethodA = &iface_CallStaticMethodA,
    .CallStaticShortMethod = &iface_CallStaticMethod,
    .CallStaticShortMethodV = &iface_CallStaticMethodV,
    .CallStaticShortMethodA = &iface_CallStaticMethodA,
    .CallStaticIntMethod = &iface_CallStaticMethod,
    .CallStaticIntMethodV = &iface_CallStaticMethodV,
    .CallStaticIntMethodA = &iface_CallStaticMethodA,
    .CallStaticLongMethod = &iface_CallStaticMethod,
    .CallStaticLongMethodV = &iface_CallStaticMethodV,
    .CallStaticLongMethodA = &iface_CallStaticMethodA,
    .CallStaticFloatMethod = &iface_CallStaticMethod,
    .CallStaticFloatMethodV = &iface_CallStaticMethodV,
    .CallStaticFloatMethodA = &iface_CallStaticMethodA,
    .CallStaticDoubleMethod = &iface_CallStaticMethod,
    .CallStaticDoubleMethodV = &iface_CallStaticMethodV,
    .CallStaticDoubleMethodA = &iface_CallStaticMethodA,
    .CallStaticVoidMethod = &iface_CallStaticMethod,
    .CallStaticVoidMethodV = &iface_CallStaticMethodV,
    .CallStaticVoidMethodA = &iface_CallStaticMethodA,
    .GetStaticFieldID = &iface_GetStaticFieldID,
    .GetStaticObjectField = &iface_GetStaticField,
    .GetStaticBooleanField = &iface_GetStaticField,
    .GetStaticByteField = &iface_GetStaticField,
    .GetStaticCharField = &iface_GetStaticField,
    .GetStaticShortField = &iface_GetStaticField,
    .GetStaticIntField = &iface_GetStaticField,
    .GetStaticLongField = &iface_GetStaticField,
    .GetStaticFloatField = &iface_GetStaticField,
    .GetStaticDoubleField = &iface_GetStaticField,
    .SetStaticObjectField = &iface_SetStaticField,
    .SetStaticBooleanField = &iface_SetStaticField,
    .SetStaticByteField = &iface_SetStaticField,
    .SetStaticCharField = &iface_SetStaticField,
    .SetStaticShortField = &iface_SetStaticField,
    .SetStaticIntField = &iface_SetStaticField,
    .SetStaticLongField = &iface_SetStaticField,
    .SetStaticFloatField = &iface_SetStaticField,
    .SetStaticDoubleField = &iface_SetStaticField,

    .NewString = &iface_NewString,
    .GetStringLength = &iface_GetStringLength,
    .GetStringChars = &iface_GetStringChars,
    .ReleaseStringChars = &iface_ReleaseStringChars,
    .NewStringUTF = &iface_NewStringUTF,
    .GetStringUTFLength = &iface_GetStringUTFLength,

    .GetStringUTFChars = &iface_GetStringUTFChars,
    .ReleaseStringUTFChars = &iface_ReleaseStringUTFChars,
    .GetArrayLength = &iface_GetArrayLength,
    .NewObjectArray = &iface_NewObjectArray,
    .GetObjectArrayElement = &iface_GetObjectArrayElement,
    .SetObjectArrayElement = &iface_SetObjectArrayElement,

    .NewBooleanArray = &iface_NewArray,
    .NewByteArray = &iface_NewArray,
    .NewCharArray = &iface_NewArray,
    .NewShortArray = &iface_NewArray,
    .NewIntArray = &iface_NewArray,
    .NewLongArray = &iface_NewArray,
    .NewFloatArray = &iface_NewArray,
    .NewDoubleArray = &iface_NewArray,
    .GetBooleanArrayElements = &iface_GetArrayElements,
    .GetByteArrayElements = &iface_GetArrayElements,
    .GetCharArrayElements = &iface_GetArrayElements,
    .GetShortArrayElements = &iface_GetArrayElements,
    .GetIntArrayElements = &iface_GetArrayElements,
    .GetLongArrayElements = &iface_GetArrayElements,
    .GetFloatArrayElements = &iface_GetArrayElements,
    .GetDoubleArrayElements = &iface_GetArrayElements,
    .ReleaseBooleanArrayElements = &iface_ReleaseArrayElements,
    .ReleaseByteArrayElements = &iface_ReleaseArrayElements,
    .ReleaseCharArrayElements = &iface_ReleaseArrayElements,
    .ReleaseShortArrayElements = &iface_ReleaseArrayElements,
    .ReleaseIntArrayElements = &iface_ReleaseArrayElements,
    .ReleaseLongArrayElements = &iface_ReleaseArrayElements,
    .ReleaseFloatArrayElements = &iface_ReleaseArrayElements,
    .ReleaseDoubleArrayElements = &iface_ReleaseArrayElements,
    .GetBooleanArrayRegion = &iface_GetArrayRegion,
    .GetByteArrayRegion = &iface_GetArrayRegion,
    .GetCharArrayRegion = &iface_GetArrayRegion,
    .GetShortArrayRegion = &iface_GetArrayRegion,
    .GetIntArrayRegion = &iface_GetArrayRegion,
    .GetLongArrayRegion = &iface_GetArrayRegion,
    .GetFloatArrayRegion = &iface_GetArrayRegion,
    .GetDoubleArrayRegion = &iface_GetArrayRegion,

    .SetBooleanArrayRegion = &iface_SetArrayRegion,
    .SetByteArrayRegion = &iface_SetArrayRegion,
    .SetCharArrayRegion = &iface_SetArrayRegion,
    .SetShortArrayRegion = &iface_SetArrayRegion,
    .SetIntArrayRegion = &iface_SetArrayRegion,
    .SetLongArrayRegion = &iface_SetArrayRegion,
    .SetFloatArrayRegion = &iface_SetArrayRegion,
    .SetDoubleArrayRegion = &iface_SetArrayRegion,
    .RegisterNatives = &iface_RegisterNatives,
    .UnregisterNatives = &iface_UnregisterNatives,
    .MonitorEnter = &iface_MonitorEnter,
    .MonitorExit = &iface_MonitorExit,
    .GetJavaVM = &iface_GetJavaVM,
    .GetStringRegion = &iface_GetStringRegion,
    .GetStringUTFRegion = &iface_GetStringUTFRegion,
    .GetPrimitiveArrayCritical = &iface_GetPrimitiveArrayCritical,
    .ReleasePrimitiveArrayCritical = &iface_ReleasePrimitiveArrayCritical,
    .GetStringCritical = &iface_GetStringCritical,
    .ReleaseStringCritical = &iface_ReleaseStringCritical,
    .NewWeakGlobalRef = &iface_NewWeakGlobalRef,
    .DeleteWeakGlobalRef = &iface_DeleteWeakGlobalRef,
    .ExceptionCheck = &iface_ExceptionCheck,
    .NewDirectByteBuffer = &iface_NewDirectByteBuffer,
    .GetDirectBufferAddress = &iface_GetDirectBufferAddress,
    .GetDirectBufferCapacity = &iface_GetDirectBufferCapacity,

    /* added in JNI 1.6 */
    .GetObjectRefType = &iface_GetObjectRefType,
};

thread_local JNIEnv *tls_env = NULL;
ABI_ATTR static jint iface_AttachCurrentThread(JavaVM *vm, JNIEnv **p_env, void *thr_args)
{
    if (tls_env == NULL) {
        tls_env = (JNIEnv*)calloc(1, sizeof(JNIEnv));
        tls_env->functions = &jnienv_funcs;
    }

    *p_env = tls_env;
    return JNI_OK;
}

ABI_ATTR static jint iface_DestroyJavaVM(JavaVM *vm)
{
    WARN_STUB;
    return 0;
}

ABI_ATTR static jint iface_DetachCurrentThread(JavaVM *vm)
{
    WARN_STUB;
    return 0;
}

ABI_ATTR static jint iface_GetEnv(JavaVM* vm, void **env, jint version)
{
    if (tls_env == NULL)
        return JNI_EDETACHED;

    *env = (void*)tls_env;
    return JNI_OK;
}

ABI_ATTR static jint iface_AttachCurrentThreadAsDaemon(JavaVM *vm, JNIEnv **env, void *thr_args)
{
    vm->AttachCurrentThread(env, thr_args);
    return JNI_OK;
}

const JNIInvokeInterface jvm_funcs = {
    .DestroyJavaVM = &iface_DestroyJavaVM,
    .AttachCurrentThread = &iface_AttachCurrentThread,
    .DetachCurrentThread = &iface_DetachCurrentThread,
    .GetEnv = &iface_GetEnv,
    .AttachCurrentThreadAsDaemon = &iface_AttachCurrentThreadAsDaemon
};

jint JNI_CreateJavaVM(JavaVM **p_vm, JNIEnv **p_env, void *vm_args)
{
    if (jvm_global == NULL) {
        jvm_global = (JavaVM*)calloc(1, sizeof(JavaVM));
        jvm_global->functions = &jvm_funcs;
    }

    jvm_global->AttachCurrentThread((JNIEnv**)p_env, NULL);
    *p_vm = jvm_global; 

    return JNI_OK;
}
