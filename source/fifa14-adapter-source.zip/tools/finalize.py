from pathlib import Path
import hashlib,zipfile
R=Path(__file__).resolve().parents[1];W=R.parent;C=R/'candidate'
# The FIFA launcher owns its intro, process lifetime and no-backup policy.
# Do not regenerate it from the earlier DuckTales launcher.
text=(C/'launch.sh').read_text()
assert 'backup=' not in text and 'tar -cf' not in text
assert 'PORT_FPS_HUD=0' in text and 'fifa14-intro' in text
text=(W/'DuckTales_ArkOS/DuckTales Remastered.sh').read_text().replace('ducktales','fifa14').replace('DuckTales Remastered','FIFA 14')
(R/'FIFA 14.sh').write_text(text,newline='\n')
with zipfile.ZipFile(C/'source/fifa14-adapter-source.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted((R/'tools').iterdir()):
  if p.suffix in ['.c','.h','.py']:z.write(p,'tools/'+p.name)
 z.write(R/'ESTADO.md','ESTADO.md')
files=[p for p in C.rglob('*') if p.is_file() and (p.relative_to(C).parts[0] not in ['userdata','reports'] or (p.relative_to(C).as_posix().startswith('userdata/Android/data/com.ea.game.fifa14_row/Speech/') and p.suffix in ['.big','.bh','.evt']) or p.relative_to(C).as_posix().endswith('/roster/console_cl.bin')) and p.name not in ['runtime.sha256','fps-overlay.cfg']]
(C/'runtime.sha256').write_text(''.join(hashlib.file_digest(p.open('rb'),'sha256').hexdigest()+'  '+p.relative_to(C).as_posix()+'\n' for p in sorted(files)),newline='\n')
print('Full extracted FIFA runtime manifest:',len(files),'files',sum(p.stat().st_size for p in files),'bytes')
