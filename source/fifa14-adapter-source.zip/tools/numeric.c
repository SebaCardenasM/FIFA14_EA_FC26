#define _GNU_SOURCE
#include <math.h>
#include <stdlib.h>
#include <dlfcn.h>
#include "platform.h"
extern void dt_add(const char*,void*);
/* The pinned ARMHF host does not bridge its libm float ABI. Guest arguments
   and results use core registers; Linux libm/GLES use VFP registers. */
#define D1(n) static double ABI_ATTR guest_##n(double x){return n(x);}
#define F1(n) static float ABI_ATTR guest_##n(float x){return n(x);}
#define D2(n) static double ABI_ATTR guest_##n(double x,double y){return n(x,y);}
#define F2(n) static float ABI_ATTR guest_##n(float x,float y){return n(x,y);}
D1(sin) D1(cos) D1(tan) D1(asin) D1(acos) D1(atan) D1(sinh) D1(cosh) D1(tanh)
D1(exp) D1(exp2) D1(log) D1(log10) D1(sqrt) D1(floor) D1(ceil) D1(fabs)
F1(sinf) F1(cosf) F1(tanf) F1(asinf) F1(acosf) F1(atanf) F1(sqrtf) F1(floorf) F1(ceilf) F1(logf) F1(expf) F1(fabsf)
D2(atan2) D2(pow) D2(fmod) F2(atan2f) F2(powf) F2(fmodf)
static double ABI_ATTR guest_ldexp(double x,int exponent){return ldexp(x,exponent);}
static double ABI_ATTR guest_frexp(double x,int*p){return frexp(x,p);}
static double ABI_ATTR guest_modf(double x,double*p){return modf(x,p);}
static double ABI_ATTR guest_strtod(const char*x,char**end){return strtod(x,end);}
static float ABI_ATTR guest_strtof(const char*x,char**end){return strtof(x,end);}
static double ABI_ATTR guest_atof(const char*x){return atof(x);}
static void ABI_ATTR clear_colour(float r,float g,float b,float a){static void(*fn)(float,float,float,float);if(!fn)fn=dlsym(RTLD_DEFAULT,"glClearColor");fn(r,g,b,a);}
static void ABI_ATTR clear_depth(float x){static void(*fn)(float);if(!fn)fn=dlsym(RTLD_DEFAULT,"glClearDepthf");fn(x);}
static void ABI_ATTR depth_range(float a,float b){static void(*fn)(float,float);if(!fn)fn=dlsym(RTLD_DEFAULT,"glDepthRangef");fn(a,b);}
static void ABI_ATTR uniform1(int location,float x){static void(*fn)(int,float);if(!fn)fn=dlsym(RTLD_DEFAULT,"glUniform1f");fn(location,x);}
static void ABI_ATTR uniform2(int location,float x,float y){static void(*fn)(int,float,float);if(!fn)fn=dlsym(RTLD_DEFAULT,"glUniform2f");fn(location,x,y);}
void dt_numeric_imports(void){
#define N(n) dt_add(#n,guest_##n)
N(sin);N(cos);N(tan);N(asin);N(acos);N(atan);N(sinh);N(cosh);N(tanh);N(exp);N(exp2);N(log);N(log10);N(sqrt);N(floor);N(ceil);N(fabs);
N(sinf);N(cosf);N(tanf);N(asinf);N(acosf);N(atanf);N(sqrtf);N(floorf);N(ceilf);N(logf);N(expf);N(fabsf);
N(atan2);N(pow);N(fmod);N(atan2f);N(powf);N(fmodf);N(ldexp);N(frexp);N(modf);N(strtod);N(strtof);N(atof);
dt_add("glClearColor",clear_colour);dt_add("glClearDepthf",clear_depth);dt_add("glDepthRangef",depth_range);dt_add("glUniform1f",uniform1);dt_add("glUniform2f",uniform2);
}
