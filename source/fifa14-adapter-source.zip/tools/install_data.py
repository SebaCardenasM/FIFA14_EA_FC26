from pathlib import Path
import sys,tarfile,time,shlex
R=Path(__file__).resolve().parents[1];C=R/'candidate';remote='/roms/ports/fifa14'
sys.path.insert(0,str(R.parent/'Blasphemous_ArkOS/tools'))
from current_card_connection import connect
files=[p for p in sorted(C.rglob('*')) if p.is_file() and p.name not in ['libfifa14.so','runtime.sha256','launch.sh']]
total=sum(p.stat().st_size for p in files)
with connect() as c:
 _,o,e=c.exec_command('test ! -e '+remote+' && test "$(df -B1 --output=avail /roms/ports | tail -n 1)" -gt '+str(total+128*1024*1024)+' && mkdir -p '+remote)
 assert o.channel.recv_exit_status()==0,e.read().decode()
 ch=c.get_transport().open_session();ch.settimeout(300);ch.exec_command('tar -xf - -C /roms/ports')
 class Stream:
  def __init__(self):self.done=0;self.last=0;self.start=time.monotonic()
  def write(self,b):
   ch.sendall(b);self.done+=len(b)
   if self.done-self.last>100*1024*1024:self.last=self.done;print(round(self.done/1024**2),'MiB of',round(total/1024**2),'MiB',round(self.done/(time.monotonic()-self.start)/1024**2,1),'MiB/s',flush=True)
   return len(b)
  def flush(self):pass
 print('Streaming extracted FIFA data and private runtime to microSD',round(total/1024**2),'MiB',flush=True)
 with tarfile.open(fileobj=Stream(),mode='w|') as tar:
  for p in files:
   n=p.relative_to(C).as_posix();info=tar.gettarinfo(str(p),'fifa14/'+n);info.uid=info.gid=1000;info.uname=info.gname='ark';info.mode=0o755 if p.suffix in ['.sh','.py'] or p.name=='fifa14-host' or n.startswith('runtime/') else 0o644
   with p.open('rb') as f:tar.addfile(info,f)
 ch.shutdown_write();error=ch.makefile_stderr('rb').read().decode();assert ch.recv_exit_status()==0,error
 print('All prepared data copied. Adapter and full integrity audit follow.',flush=True)
