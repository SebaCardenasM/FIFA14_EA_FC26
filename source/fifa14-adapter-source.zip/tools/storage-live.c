#define _GNU_SOURCE
#include <stdbool.h>
#include <link.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <sys/mman.h>
#include "so_util.h"
#include "active-layout.h"
extern int fifa14_android_statfs(const char*,void*);
static uintptr_t base;
static int locate(struct dl_phdr_info*i,size_t n,void*p){const char*s=strrchr(i->dlpi_name,'/');if(!strcmp(s?s+1:i->dlpi_name,"libfifa14.so")){base=i->dlpi_addr;return 1;}return 0;}
__attribute__((constructor))static void install(void){
 dl_iterate_phdr(locate,NULL);if(!base)return;
 so_module*m=*(so_module**)(base+ACTIVE_game);if(!m)return;
 uintptr_t*got=(void*)(m->text_base+0x10e7cac);if(mprotect((void*)((uintptr_t)got&~4095u),4096,PROT_READ|PROT_WRITE))return;
 *got=(uintptr_t)fifa14_android_statfs;
 fprintf(stderr,"[fifa14/storage] Bionic ARM space-query bridge active\n");
}
