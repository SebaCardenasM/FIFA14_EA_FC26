#define _GNU_SOURCE
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <sys/vfs.h>
#include "platform.h"
/* Bionic ARM statfs uses 64-bit block counters and four-byte packing.
   glibc ARM statfs has 32-bit counters. Passing it directly reports zero
   fragment size to EAIO; the native caller reads f_frsize at byte 60. */
typedef struct __attribute__((packed,aligned(4))){
 uint32_t type,bsize;uint64_t blocks,bfree,bavail,files,ffree;
 uint32_t fsid[2],namelen,frsize,flags,spare[4];
} AndroidStatFs;
_Static_assert(sizeof(AndroidStatFs)==84,"Bionic ARM statfs layout");
int ABI_ATTR fifa14_android_statfs(const char*path,AndroidStatFs*out){
 char mapped[4096],root[3072];const char*p=path;
 if(path&&!strncmp(path,"/sdcard",7)){if(!getcwd(root,sizeof(root)))return -1;snprintf(mapped,sizeof(mapped),"%s/userdata%s",root,path+7);p=mapped;}
 struct statfs64 f;int result=statfs64(p,&f);if(result)return result;
 memset(out,0,sizeof(*out));out->type=f.f_type;out->bsize=f.f_bsize;out->blocks=f.f_blocks;out->bfree=f.f_bfree;out->bavail=f.f_bavail;out->files=f.f_files;out->ffree=f.f_ffree;
 memcpy(out->fsid,&f.f_fsid,sizeof(out->fsid));out->namelen=f.f_namelen;out->frsize=f.f_frsize?f.f_frsize:f.f_bsize;out->flags=f.f_flags;
 fprintf(stderr,"[fifa14/storage] path=%s available_bytes=%llu fragment=%u\n",p,(unsigned long long)(out->bavail*out->frsize),out->frsize);
 return 0;
}
