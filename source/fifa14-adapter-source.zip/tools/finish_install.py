from pathlib import Path
import sys,shlex,json,hashlib
R=Path(__file__).resolve().parents[1];C=R/'candidate';remote='/roms/ports/fifa14'
sys.path.insert(0,str(R.parent/'Blasphemous_ArkOS/tools'))
from current_card_connection import connect
with connect() as c:
 _,o,e=c.exec_command('! pgrep -f "(^|/| )(ducktales-host|fifa14-host|unity6-gles3|evoland2-host)( |$)" >/dev/null');assert o.channel.recv_exit_status()==0,e.read().decode()
 with c.open_sftp() as s:
  for n in ['libfifa14.so','launch.sh','runtime.sha256']:
   s.put(str(C/n),remote+'/'+n+'.updating');s.posix_rename(remote+'/'+n+'.updating',remote+'/'+n)
  s.chmod(remote+'/launch.sh',0o755)
 _,o,e=c.exec_command('cd '+remote+' && mkdir -p reports userdata cache && bash -n launch.sh && ./runtime/ld-linux-armhf.so.3 --library-path ./runtime/lib --list ./fifa14-host && python3 verify-runtime.py >reports/install-integrity.log && echo FIFA_FULL_INSTALL_OK',timeout=180)
 print(o.read().decode()+e.read().decode(),flush=True);assert o.channel.recv_exit_status()==0
 script="from pathlib import Path;import json,hashlib;r=Path("+repr(remote)+");cache=json.loads((r/'.runtime-verified.json').read_text());(r/'.runtime-offline-verified.json').write_text(json.dumps({'schema':1,'runtime_manifest_sha256':hashlib.sha256((r/'runtime.sha256').read_bytes()).hexdigest(),'files':{n:[v[0],v[1],v[2]] for n,v in cache.items()}}))"
 _,o,e=c.exec_command('python3 -c '+shlex.quote(script));assert o.channel.recv_exit_status()==0,e.read().decode()
print('FIFA data, adapter and private dependencies installed and verified')
