#define _GNU_SOURCE
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <unistd.h>
#include <dlfcn.h>
#include <pthread.h>
#include <sys/mman.h>
#include <signal.h>
#include <ucontext.h>
#include <time.h>
#include "so_util.h"
#include "jni.h"
#include "offsets.h"
#include "imports.h"

uintptr_t host_base;static so_module*game;static JavaVM*vm;static JNIEnv*env;
static char root[4096],save[4096],obb[4096];static volatile int quit;
static DynLibFunction extra[8192],combined[12288];static unsigned extra_count;
static const struct JNINativeInterface*original;static struct JNINativeInterface local;
static const struct JNIInvokeInterface*old_vm;static struct JNIInvokeInterface local_vm;
static jobject activity,assets;
static int video_pending=-1,video_delay;
typedef struct{char name[160];} FakeClass;
typedef struct{FakeClass*cls;char path[1024];int descriptor;} FakeObject;
typedef struct{jclass cls;char name[160],sig[200];jobject value;} FakeMethod;
typedef struct{jsize count;jobject*items;unsigned refs;} ObjectArray;
static ObjectArray arrays[512];static unsigned array_count;
static FakeClass classes[128];static unsigned class_count;
static FakeObject objects[1024];static unsigned object_count;
static FakeMethod methods[512];static unsigned method_count;static pthread_mutex_t registry_lock=PTHREAD_MUTEX_INITIALIZER;
void dt_add(const char*n,void*p){if(p&&extra_count<8190)extra[extra_count++]=(DynLibFunction){n,(uintptr_t)p};}
static void*ABI_ATTR egl_current_display(void){return(void*)0xe61d1591;}
static const unsigned char*ABI_ATTR driver_string(unsigned name){const unsigned char*(*fn)(unsigned)=dlsym(RTLD_DEFAULT,"glGetString");void*(*current)(void)=dlsym(RTLD_NEXT,"SDL_GL_GetCurrentContext");const unsigned char*p=fn?fn(name):NULL;fprintf(stderr,"[fifa14/gl] string=%x context=%p value=%s\n",name,current?current():NULL,p?(name==0x1f03?"extensions available":(const char*)p):"NULL");return p;}
static void builtin_loaded(const char*replace,const char*loaded){const char**list=(void*)(host_base+HOST_builtin);for(unsigned i=0;list[i];i++)if(!strcmp(list[i],replace)){list[i]=loaded;return;}fprintf(stderr,"[fifa14] no dependency slot for %s\n",loaded);_exit(64);}
void dt_input_set_quit(void){quit=1;}
static int fake_class(jclass c){return (uintptr_t)c>=(uintptr_t)classes&&(uintptr_t)c<(uintptr_t)(classes+class_count);}
static int object_array(jobject o){return(uintptr_t)o>=(uintptr_t)arrays&&(uintptr_t)o<(uintptr_t)(arrays+array_count);}
static int fake_object(jobject o){return o==activity||object_array(o)||fake_class((jclass)o)||((uintptr_t)o>=(uintptr_t)objects&&(uintptr_t)o<(uintptr_t)(objects+object_count));}
static int fake_method(void*m){return(uintptr_t)m>=(uintptr_t)methods&&(uintptr_t)m<(uintptr_t)(methods+method_count);}
static FakeClass*get_class(const char*n){pthread_mutex_lock(&registry_lock);for(unsigned i=0;i<class_count;i++)if(!strcmp(classes[i].name,n)){pthread_mutex_unlock(&registry_lock);return classes+i;}if(class_count>=128)_exit(61);FakeClass*c=classes+class_count++;snprintf(c->name,sizeof(c->name),"%s",n);pthread_mutex_unlock(&registry_lock);fprintf(stderr,"[fifa14/java] class %s\n",n);return c;}
static FakeObject*new_object(FakeClass*c){pthread_mutex_lock(&registry_lock);if(object_count>=1024)_exit(62);FakeObject*o=objects+object_count++;o->cls=c;pthread_mutex_unlock(&registry_lock);return o;}
static void*get_method(jclass c,const char*n,const char*s){pthread_mutex_lock(&registry_lock);for(unsigned i=0;i<method_count;i++)if(methods[i].cls==c&&!strcmp(methods[i].name,n)&&!strcmp(methods[i].sig,s)){pthread_mutex_unlock(&registry_lock);return methods+i;}if(method_count>=512)_exit(63);FakeMethod*m=methods+method_count++;m->cls=c;snprintf(m->name,sizeof(m->name),"%s",n);snprintf(m->sig,sizeof(m->sig),"%s",s);pthread_mutex_unlock(&registry_lock);fprintf(stderr,"[fifa14/java] %s %s %s\n",fake_class(c)?((FakeClass*)c)->name:"extended class",n,s);return m;}
static jclass ABI_ATTR j_find(JNIEnv*e,const char*n){for(unsigned i=0;i<class_count;i++)if(!strcmp(classes[i].name,n))return(jclass)(classes+i);jclass c=original->FindClass(e,n);return c?c:(jclass)get_class(n);}
static jclass ABI_ATTR j_class(JNIEnv*e,jobject o){if(o==activity)return(jclass)get_class("com/ea/game/fifa14/Fifa14Activity");if((uintptr_t)o>=(uintptr_t)objects&&(uintptr_t)o<(uintptr_t)(objects+object_count))return(jclass)((FakeObject*)o)->cls;return original->GetObjectClass(e,o);}
static jmethodID ABI_ATTR j_method(JNIEnv*e,jclass c,const char*n,const char*s){if(!strcmp(n,"loadClass")||!strcmp(n,"GetLanguage")||!strcmp(n,"GetLocale"))return(jmethodID)get_method(c,n,s);jmethodID m=fake_class(c)?NULL:original->GetMethodID(e,c,n,s);return m?m:(jmethodID)get_method(c,n,s);}
static jmethodID ABI_ATTR j_static(JNIEnv*e,jclass c,const char*n,const char*s){if(!strcmp(n,"GetLanguage")||!strcmp(n,"GetLocale"))return(jmethodID)get_method(c,n,s);jmethodID m=fake_class(c)?NULL:original->GetStaticMethodID(e,c,n,s);return m?m:(jmethodID)get_method(c,n,s);}
static jobject object_value(JNIEnv*e,jobject self,FakeMethod*m){
 const char*n=m->name;char path[4096];
 if(!strcmp(n,"getClassLoader")){if(!m->value)m->value=(jobject)new_object(get_class("java/lang/ClassLoader"));return m->value;}
 if(!strcmp(n,"GetTheVersion"))return original->NewStringUTF(e,"1.3.6");
 if(!strcmp(n,"getComponent")||!strcmp(n,"getStatus")){if(!m->value){const char*p=strchr(m->sig,')');if(p&&p[1]=='L'){snprintf(path,sizeof(path),"%s",p+2);char*end=strchr(path,';');if(end)*end=0;m->value=(jobject)new_object(get_class(path));}}return m->value;}
 if(!strcmp(n,"GetGLView")||!strcmp(n,"getGLView")||!strcmp(n,"GetViewRoot")){if(!m->value)m->value=(jobject)new_object(get_class(strstr(n,"Root")?"android/view/ViewRoot":"android/opengl/GLSurfaceView"));return m->value;}
 if(!strcmp(n,"GetInstance")||!strcmp(n,"getInstance")||strstr(n,"getActivity")||strstr(n,"getContext"))return activity;
 if(!strcmp(n,"getAssets"))return assets;
 if(!strcmp(n,"getResources"))return(jobject)new_object(get_class("android/content/res/Resources"));
 if(!strcmp(n,"getDisplayMetrics"))return(jobject)new_object(get_class("android/util/DisplayMetrics"));
 if(!strcmp(n,"getPackageName")||!strcmp(n,"GetThePackage"))return original->NewStringUTF(e,"com.ea.game.fifa14_row");
 if(!strcmp(n,"getFileDescriptor")){FakeObject*o=new_object(get_class("java/io/FileDescriptor"));o->descriptor=*(int*)(host_base+HOST_asset_fd);return(jobject)o;}
 if(!strcmp(n,"getExternalStorageState"))return original->NewStringUTF(e,"mounted");
 if(!strcmp(n,"getLanguage")||!strcmp(n,"GetLanguage"))return original->NewStringUTF(e,"es");
 if(!strcmp(n,"getLocale")||!strcmp(n,"GetLocale"))return original->NewStringUTF(e,"es_ES");
 if(!strcmp(n,"getCountry"))return original->NewStringUTF(e,"ES");
 if(strstr(n,"OBB")||strstr(n,"Obb")){if(strstr(m->sig,"Ljava/io/File;")){FakeObject*o=new_object(get_class("java/io/File"));snprintf(o->path,sizeof(o->path),"%s/obb",root);return(jobject)o;}return original->NewStringUTF(e,obb);}
 if(strstr(n,"getPath")||strstr(n,"getAbsolutePath")){const char*p=save;if((uintptr_t)self>=(uintptr_t)objects&&(uintptr_t)self<(uintptr_t)(objects+object_count)&&((FakeObject*)self)->path[0])p=((FakeObject*)self)->path;return original->NewStringUTF(e,p);}
 if(strstr(n,"Directory")||strstr(n,"FilesDir")||strstr(n,"CacheDir")||strstr(n,"Storage")){if(strstr(m->sig,"Ljava/io/File;")){FakeObject*o=new_object(get_class("java/io/File"));snprintf(o->path,sizeof(o->path),"%s",save);return(jobject)o;}return original->NewStringUTF(e,save);}
 if(strstr(m->sig,"Ljava/lang/String;")){if(strstr(n,"locale")||strstr(n,"Locale"))return original->NewStringUTF(e,"es_ES");return original->NewStringUTF(e,"");}
 if(strstr(m->sig,"[Ljava/lang/String;"))return original->NewObjectArray(e,0,original->FindClass(e,"java/lang/String"),NULL);
 return NULL;
}
static jint int_value(FakeMethod*m){const char*n=m->name;if(!strcmp(n,"GetTheVersionCode"))return 136;if(strstr(n,"Width")||!strcmp(n,"widthPixels")||!strcmp(n,"width"))return 640;if(strstr(n,"Height")||!strcmp(n,"heightPixels")||!strcmp(n,"height"))return 480;if(strstr(n,"Count")||strstr(n,"SDK")||strstr(n,"Version"))return strstr(n,"SDK")?22:1;if(strstr(n,"Gamepad")||strstr(n,"Joystick"))return 1;return 0;}
static jlong long_value(FakeMethod*m){struct timespec t;if(strstr(m->name,"nanoTime")){clock_gettime(CLOCK_MONOTONIC,&t);return(jlong)t.tv_sec*1000000000+t.tv_nsec;}if(strstr(m->name,"TimeMillis")||strstr(m->name,"elapsedRealtime")||strstr(m->name,"uptimeMillis")){clock_gettime(strstr(m->name,"current")?CLOCK_REALTIME:CLOCK_MONOTONIC,&t);return(jlong)t.tv_sec*1000+t.tv_nsec/1000000;}return 0;}
static jfloat float_value(FakeMethod*m){if(strstr(m->name,"ensity")||strstr(m->name,"Scale"))return 1.0f;if(strstr(m->name,"Dpi")||strstr(m->name,"DPI"))return 160.0f;return 0.0f;}
static jobject load_class(JNIEnv*e,jstring s){if(!s)return NULL;const char*p=original->GetStringUTFChars(e,s,NULL);if(!p)return NULL;char name[256];snprintf(name,sizeof(name),"%s",p);original->ReleaseStringUTFChars(e,s,p);for(char*q=name;*q;q++)if(*q=='.')*q='/';return(jobject)j_find(e,name);}
static jobject ABI_ATTR object_v(JNIEnv*e,jobject o,jmethodID m,va_list a){if(fake_method(m)&&!strcmp(((FakeMethod*)m)->name,"loadClass"))return load_class(e,va_arg(a,jstring));return fake_method(m)?object_value(e,o,(FakeMethod*)m):original->CallObjectMethodV(e,o,m,a);}
static jobject ABI_ATTR object_a(JNIEnv*e,jobject o,jmethodID m,const jvalue*a){if(fake_method(m)&&!strcmp(((FakeMethod*)m)->name,"loadClass"))return load_class(e,a[0].l);return fake_method(m)?object_value(e,o,(FakeMethod*)m):original->CallObjectMethodA(e,o,m,a);}
static jobject ABI_ATTR object_call(JNIEnv*e,jobject o,jmethodID m,...){va_list a;va_start(a,m);jobject r=object_v(e,o,m,a);va_end(a);return r;}
static jint ABI_ATTR int_v(JNIEnv*e,jobject o,jmethodID m,va_list a){return fake_method(m)?int_value((FakeMethod*)m):original->CallIntMethodV(e,o,m,a);}
static jint ABI_ATTR int_a(JNIEnv*e,jobject o,jmethodID m,const jvalue*a){return fake_method(m)?int_value((FakeMethod*)m):original->CallIntMethodA(e,o,m,a);}
static jint ABI_ATTR int_call(JNIEnv*e,jobject o,jmethodID m,...){va_list a;va_start(a,m);jint r=int_v(e,o,m,a);va_end(a);return r;}
static jboolean ABI_ATTR bool_v(JNIEnv*e,jobject o,jmethodID m,va_list a){return fake_method(m)?int_value((FakeMethod*)m)!=0:original->CallBooleanMethodV(e,o,m,a);}
static jboolean ABI_ATTR bool_a(JNIEnv*e,jobject o,jmethodID m,const jvalue*a){return fake_method(m)?int_value((FakeMethod*)m)!=0:original->CallBooleanMethodA(e,o,m,a);}
static jboolean ABI_ATTR bool_call(JNIEnv*e,jobject o,jmethodID m,...){va_list a;va_start(a,m);jboolean r=bool_v(e,o,m,a);va_end(a);return r;}
static void do_void(jobject o,FakeMethod*m){if(!strcmp(m->name,"finish")||!strcmp(m->name,"exitApplication"))quit=1;if(!strcmp(m->name,"play")&&(uintptr_t)o>=(uintptr_t)objects&&(uintptr_t)o<(uintptr_t)(objects+object_count)&&!strcmp(((FakeObject*)o)->cls->name,"com/ea/VideoPlayer/PlayerAndroid")){video_pending=((FakeObject*)o)->descriptor;video_delay=2;fprintf(stderr,"[fifa14/video] optional Java video unavailable; completion queued id=%d\n",video_pending);}}
static void ABI_ATTR void_v(JNIEnv*e,jobject o,jmethodID m,va_list a){if(fake_method(m)){do_void(o,(FakeMethod*)m);return;}original->CallVoidMethodV(e,o,m,a);}
static void ABI_ATTR void_a(JNIEnv*e,jobject o,jmethodID m,const jvalue*a){if(fake_method(m)){do_void(o,(FakeMethod*)m);return;}original->CallVoidMethodA(e,o,m,a);}
static void ABI_ATTR void_call(JNIEnv*e,jobject o,jmethodID m,...){va_list a;va_start(a,m);void_v(e,o,m,a);va_end(a);}
static jlong ABI_ATTR long_v(JNIEnv*e,jobject o,jmethodID m,va_list a){return fake_method(m)?long_value((FakeMethod*)m):original->CallLongMethodV(e,o,m,a);}
static jlong ABI_ATTR long_a(JNIEnv*e,jobject o,jmethodID m,const jvalue*a){return fake_method(m)?long_value((FakeMethod*)m):original->CallLongMethodA(e,o,m,a);}
static jlong ABI_ATTR long_call(JNIEnv*e,jobject o,jmethodID m,...){va_list a;va_start(a,m);jlong r=long_v(e,o,m,a);va_end(a);return r;}
#define STATIC_CALLS(TYPE,ctype,stem,expression) \
static ctype ABI_ATTR static_##stem##_v(JNIEnv*e,jclass c,jmethodID m,va_list a){if(fake_method(m))return(expression);return original->CallStatic##TYPE##MethodV(e,c,m,a);} \
static ctype ABI_ATTR static_##stem##_a(JNIEnv*e,jclass c,jmethodID m,const jvalue*a){if(fake_method(m))return(expression);return original->CallStatic##TYPE##MethodA(e,c,m,a);} \
static ctype ABI_ATTR static_##stem##_call(JNIEnv*e,jclass c,jmethodID m,...){va_list a;va_start(a,m);ctype r=static_##stem##_v(e,c,m,a);va_end(a);return r;}
STATIC_CALLS(Object,jobject,object,object_value(e,(jobject)c,(FakeMethod*)m))
STATIC_CALLS(Int,jint,int,int_value((FakeMethod*)m))
STATIC_CALLS(Boolean,jboolean,bool,int_value((FakeMethod*)m)!=0)
STATIC_CALLS(Long,jlong,long,long_value((FakeMethod*)m))
#define FLOAT_METHODS(TYPE,ctype,stem) \
static ctype ABI_ATTR stem##_v(JNIEnv*e,jobject o,jmethodID m,va_list a){if(fake_method(m))return(ctype)float_value((FakeMethod*)m);ctype ABI_ATTR(*f)(JNIEnv*,jobject,jmethodID,va_list)=(void*)original->Call##TYPE##MethodV;return f(e,o,m,a);} \
static ctype ABI_ATTR stem##_a(JNIEnv*e,jobject o,jmethodID m,const jvalue*a){if(fake_method(m))return(ctype)float_value((FakeMethod*)m);ctype ABI_ATTR(*f)(JNIEnv*,jobject,jmethodID,const jvalue*)=(void*)original->Call##TYPE##MethodA;return f(e,o,m,a);} \
static ctype ABI_ATTR stem##_call(JNIEnv*e,jobject o,jmethodID m,...){va_list a;va_start(a,m);ctype r=stem##_v(e,o,m,a);va_end(a);return r;} \
static ctype ABI_ATTR static_##stem##_v(JNIEnv*e,jclass c,jmethodID m,va_list a){if(fake_method(m))return(ctype)float_value((FakeMethod*)m);ctype ABI_ATTR(*f)(JNIEnv*,jclass,jmethodID,va_list)=(void*)original->CallStatic##TYPE##MethodV;return f(e,c,m,a);} \
static ctype ABI_ATTR static_##stem##_a(JNIEnv*e,jclass c,jmethodID m,const jvalue*a){if(fake_method(m))return(ctype)float_value((FakeMethod*)m);ctype ABI_ATTR(*f)(JNIEnv*,jclass,jmethodID,const jvalue*)=(void*)original->CallStatic##TYPE##MethodA;return f(e,c,m,a);} \
static ctype ABI_ATTR static_##stem##_call(JNIEnv*e,jclass c,jmethodID m,...){va_list a;va_start(a,m);ctype r=static_##stem##_v(e,c,m,a);va_end(a);return r;}
FLOAT_METHODS(Float,jfloat,float)
FLOAT_METHODS(Double,jdouble,double)
static void ABI_ATTR static_void_v(JNIEnv*e,jclass c,jmethodID m,va_list a){if(fake_method(m)){do_void((jobject)c,(FakeMethod*)m);return;}original->CallStaticVoidMethodV(e,c,m,a);}
static void ABI_ATTR static_void_a(JNIEnv*e,jclass c,jmethodID m,const jvalue*a){if(fake_method(m)){do_void((jobject)c,(FakeMethod*)m);return;}original->CallStaticVoidMethodA(e,c,m,a);}
static void ABI_ATTR static_void_call(JNIEnv*e,jclass c,jmethodID m,...){va_list a;va_start(a,m);static_void_v(e,c,m,a);va_end(a);}
static jobject ABI_ATTR new_v(JNIEnv*e,jclass c,jmethodID m,va_list a){if(fake_class(c)){FakeObject*o=new_object((FakeClass*)c);if(strstr(((FakeClass*)c)->name,"java/io/File")){jstring s=va_arg(a,jstring);const char*p=original->GetStringUTFChars(e,s,NULL);if(p){snprintf(o->path,sizeof(o->path),"%s",p);original->ReleaseStringUTFChars(e,s,p);}}return(jobject)o;}return original->NewObjectV(e,c,m,a);}
static jobject ABI_ATTR new_a(JNIEnv*e,jclass c,jmethodID m,const jvalue*a){if(fake_class(c))return(jobject)new_object((FakeClass*)c);return original->NewObjectA(e,c,m,a);}
static jobject ABI_ATTR new_call(JNIEnv*e,jclass c,jmethodID m,...){va_list a;va_start(a,m);jobject r=new_v(e,c,m,a);va_end(a);return r;}
static jobject ABI_ATTR global_ref(JNIEnv*e,jobject o){if(object_array(o)){((ObjectArray*)o)->refs++;return o;}return fake_object(o)?o:original->NewGlobalRef(e,o);}
static jboolean ABI_ATTR instance_of(JNIEnv*e,jobject o,jclass c){if(fake_object(o)||fake_class(c))return o&&j_class(e,o)==c;return original->IsInstanceOf(e,o,c);}
static jobjectArray ABI_ATTR new_object_array(JNIEnv*e,jsize n,jclass c,jobject init){if(n<0||n>1048576)return NULL;unsigned slot=0;while(slot<array_count&&arrays[slot].refs)slot++;if(slot==512)return NULL;if(slot==array_count)array_count++;ObjectArray*a=arrays+slot;a->count=n;a->items=calloc(n?n:1,sizeof(jobject));if(!a->items)return NULL;a->refs=1;for(int i=0;i<n;i++)a->items[i]=init;return(jobjectArray)a;}
static jsize ABI_ATTR array_length(JNIEnv*e,jarray a){return object_array((jobject)a)?((ObjectArray*)a)->count:original->GetArrayLength(e,a);}
static jobject ABI_ATTR array_get(JNIEnv*e,jobjectArray a,jsize i){if(!object_array((jobject)a))return original->GetObjectArrayElement(e,a,i);ObjectArray*p=(void*)a;return i>=0&&i<p->count?p->items[i]:NULL;}
static void ABI_ATTR array_set(JNIEnv*e,jobjectArray a,jsize i,jobject v){if(!object_array((jobject)a)){original->SetObjectArrayElement(e,a,i,v);return;}ObjectArray*p=(void*)a;if(i>=0&&i<p->count)p->items[i]=v;}
static void release_array(jobject o){ObjectArray*a=(void*)o;if(a->refs&&!--a->refs){free(a->items);a->items=NULL;a->count=0;}}
static void ABI_ATTR delete_global(JNIEnv*e,jobject o){if(object_array(o))release_array(o);else if(!fake_object(o))original->DeleteGlobalRef(e,o);}
static void ABI_ATTR delete_local(JNIEnv*e,jobject o){if(object_array(o))release_array(o);else if(!fake_object(o))original->DeleteLocalRef(e,o);}
static jfieldID ABI_ATTR field(JNIEnv*e,jclass c,const char*n,const char*s){jfieldID f=fake_class(c)?NULL:original->GetFieldID(e,c,n,s);return f?f:(jfieldID)get_method(c,n,s);}
static jfieldID ABI_ATTR static_field(JNIEnv*e,jclass c,const char*n,const char*s){jfieldID f=fake_class(c)?NULL:original->GetStaticFieldID(e,c,n,s);return f?f:(jfieldID)get_method(c,n,s);}
static jobject ABI_ATTR object_field(JNIEnv*e,jobject o,jfieldID f){return fake_method(f)?object_value(e,o,(FakeMethod*)f):original->GetObjectField(e,o,f);}
static jint ABI_ATTR int_field(JNIEnv*e,jobject o,jfieldID f){if(fake_method(f)&&!strcmp(((FakeMethod*)f)->name,"descriptor")&&(uintptr_t)o>=(uintptr_t)objects&&(uintptr_t)o<(uintptr_t)(objects+object_count))return((FakeObject*)o)->descriptor;return fake_method(f)?int_value((FakeMethod*)f):original->GetIntField(e,o,f);}
static void ABI_ATTR set_int_field(JNIEnv*e,jobject o,jfieldID f,jint v){if(fake_method(f)){if((uintptr_t)o>=(uintptr_t)objects&&(uintptr_t)o<(uintptr_t)(objects+object_count)){((FakeObject*)o)->descriptor=v;fprintf(stderr,"[fifa14/java] set %s=%d\n",((FakeMethod*)f)->name,v);}return;}original->SetIntField(e,o,f,v);}
static jboolean ABI_ATTR bool_field(JNIEnv*e,jobject o,jfieldID f){return fake_method(f)?int_value((FakeMethod*)f)!=0:original->GetBooleanField(e,o,f);}
static jobject ABI_ATTR static_object_field(JNIEnv*e,jclass c,jfieldID f){return fake_method(f)?object_value(e,(jobject)c,(FakeMethod*)f):original->GetStaticObjectField(e,c,f);}
static jint ABI_ATTR static_int_field(JNIEnv*e,jclass c,jfieldID f){return fake_method(f)?int_value((FakeMethod*)f):original->GetStaticIntField(e,c,f);}
static jboolean ABI_ATTR static_bool_field(JNIEnv*e,jclass c,jfieldID f){return fake_method(f)?int_value((FakeMethod*)f)!=0:original->GetStaticBooleanField(e,c,f);}
static jint ABI_ATTR register_native(JNIEnv*e,jclass c,const JNINativeMethod*m,jint count){if(fake_class(c)){fprintf(stderr,"[fifa14/java] register %s count=%d\n",((FakeClass*)c)->name,count);return 0;}return original->RegisterNatives(e,c,m,count);}
static jint ABI_ATTR attach(JavaVM*v,JNIEnv**e,void*args){int r=old_vm->AttachCurrentThread(v,e,args);if(!r)**e=&local;return r;}
static jint ABI_ATTR get_env(JavaVM*v,void**e,jint version){int r=old_vm->GetEnv(v,e,version);if(!r)*(JNIEnv*)*e=&local;return r;}
static void java_init(void){int(*create)(JavaVM**,JNIEnv**,void*)=(void*)(host_base+HOST_create_vm);if(create(&vm,&env,NULL))_exit(31);original=*env;local=*original;
local.FindClass=j_find;local.GetObjectClass=j_class;local.GetMethodID=j_method;local.GetStaticMethodID=j_static;local.NewObject=new_call;local.NewObjectV=new_v;local.NewObjectA=new_a;local.NewGlobalRef=global_ref;local.DeleteGlobalRef=delete_global;local.DeleteLocalRef=delete_local;local.GetFieldID=field;local.GetStaticFieldID=static_field;local.GetObjectField=object_field;local.GetStaticObjectField=(void*)object_field;local.GetIntField=int_field;local.GetStaticIntField=(void*)int_field;local.GetBooleanField=bool_field;local.GetStaticBooleanField=(void*)bool_field;local.RegisterNatives=register_native;
#define METHODS(TYPE,stem) local.Call##TYPE##Method=stem##_call;local.Call##TYPE##MethodV=stem##_v;local.Call##TYPE##MethodA=stem##_a;local.CallStatic##TYPE##Method=static_##stem##_call;local.CallStatic##TYPE##MethodV=static_##stem##_v;local.CallStatic##TYPE##MethodA=static_##stem##_a
METHODS(Object,object);METHODS(Int,int);METHODS(Boolean,bool);METHODS(Void,void);METHODS(Long,long);METHODS(Float,float);METHODS(Double,double);
local.GetStaticObjectField=static_object_field;local.GetStaticIntField=static_int_field;local.GetStaticBooleanField=static_bool_field;
*env=&local;old_vm=*vm;local_vm=*old_vm;local_vm.AttachCurrentThread=attach;local_vm.GetEnv=get_env;local_vm.AttachCurrentThreadAsDaemon=attach;*vm=&local_vm;
local.NewLocalRef=global_ref;local.IsInstanceOf=instance_of;local.NewObjectArray=new_object_array;local.GetArrayLength=array_length;local.GetObjectArrayElement=array_get;local.SetObjectArrayElement=array_set;
local.SetIntField=set_int_field;
jobject(*get_activity)(JNIEnv*,jclass)=(void*)(host_base+HOST_get_activity);activity=get_activity(env,NULL);jobject(*get_assets)(JNIEnv*,jobject)=(void*)(host_base+HOST_get_assets);assets=get_assets(env,activity);}

static void crash(int sig,siginfo_t*i,void*ctx){ucontext_t*u=ctx;dprintf(2,"[fifa14/crash] signal=%d fault=%p pc=%lx lr=%lx sp=%lx host=%lx game=%lx\n",sig,i->si_addr,u->uc_mcontext.arm_pc,u->uc_mcontext.arm_lr,u->uc_mcontext.arm_sp,(unsigned long)host_base,game?(unsigned long)game->text_base:0);unsigned long*r=&u->uc_mcontext.arm_r0;for(int j=0;j<13;j++)dprintf(2,"r%d=%lx ",j,r[j]);unsigned long*s=(void*)u->uc_mcontext.arm_sp;for(int j=0;j<32;j++)dprintf(2,"\nsp+%x=%lx",j*4,s[j]);dprintf(2,"\n");_exit(128+sig);}
static void patch_host(uintptr_t address,void*fn){uintptr_t a=address&~1u;mprotect((void*)(a&~4095u),8192,PROT_READ|PROT_WRITE|PROT_EXEC);unsigned char*p=(void*)a;if(address&1){if(a&2){*(uint16_t*)p=0xbf00;p+=2;}*(uint16_t*)p=0xf8df;*(uint16_t*)(p+2)=0xf000;*(uint32_t*)(p+4)=(uintptr_t)fn;}else{*(uint32_t*)p=0xe51ff004;*(uint32_t*)(p+4)=(uintptr_t)fn;}__builtin___clear_cache((char*)a,(char*)a+12);}
static uintptr_t symbol(so_module*m,const char*n){uintptr_t(*f)(so_module*,const char*)=(void*)(host_base+HOST_symbol);return f(m,n);}
static int after(so_module*m){fprintf(stderr,"[fifa14/loader] linked %s base=%lx\n",m->soname?m->soname:"native module",(unsigned long)m->text_base);uintptr_t(*resolve)(so_module*,const char*)=(void*)(host_base+HOST_resolve);int missing=0;for(int i=0;i<m->num_dynsym;i++){Elf_Sym*s=m->dynsym+i;if(s->st_shndx!=SHN_UNDEF||!s->st_name||(s->st_info>>4)==2)continue;const char*n=m->dynstr+s->st_name;if(!resolve(m,n)){fprintf(stderr,"[fifa14/missing] %s\n",n);missing++;}}return missing?1:0;}
static const char*fix_path(const char*orig,char*buf,size_t n){if(!orig)return orig;const char*p=strstr(orig,"/Android/obb/");if(p){p=strrchr(orig,'/');snprintf(buf,n,"%s/obb/%s",root,p?p+1:orig);return buf;}if(!strncmp(orig,"appbundle:/",11)){p=orig+11;while(*p=='/')p++;snprintf(buf,n,"%s/assets/%s",root,p);return buf;}if(!strncmp(orig,"appdata:/",9)){snprintf(buf,n,"%s/%s",save,orig+9);return buf;}if(!strncmp(orig,"/sdcard/",8)){snprintf(buf,n,"%s/%s",save,orig+8);return buf;}return orig;}
void dt_numeric_imports(void);
void fifa14_wide_imports(void);
void fifa14_wide_init(uintptr_t);
int ABI_ATTR fifa14_android_statfs(const char*,void*);
static void*find(DynLibFunction**t,const char*n){for(unsigned i=0;t[i];i++)for(unsigned j=0;t[i][j].symbol;j++)if(!strcmp(n,t[i][j].symbol))return(void*)t[i][j].func;return NULL;}
static void refresh(DynLibFunction**tables,DynLibFunction*first){unsigned n=0;for(unsigned i=0;i<extra_count;i++)combined[n++]=extra[i];for(unsigned i=0;first[i].symbol;i++)combined[n++]=first[i];combined[n]=(DynLibFunction){0};tables[0]=combined;}
static so_module*load(const char*n){so_module*(*f)(const char*,void*,void*)=(void*)(host_base+HOST_load);fprintf(stderr,"[fifa14/loader] loading %s\n",n);return f(n,NULL,NULL);}
static uintptr_t entry(const char*n){return symbol(game,n);}
static void invoke0(const char*n){void ABI_ATTR(*fn)(JNIEnv*,jobject)=(void*)entry(n);if(fn){fprintf(stderr,"[fifa14/boot] %s\n",n);fn(env,activity);}}
void fifa14_controls_init(JNIEnv*,jobject,so_module*,uintptr_t,int);
void fifa14_controls_tick(void*);
static void fifa14_input_tick(void*pad){
 if(video_pending>=0&&!--video_delay){int id=video_pending;video_pending=-1;void ABI_ATTR(*complete)(JNIEnv*,jobject,int)=(void*)entry("Java_com_ea_VideoPlayer_PlayerAndroid_OnCompletionNativeImpl");if(complete){fprintf(stderr,"[fifa14/video] completion id=%d\n",id);complete(env,activity,id);}}
 fifa14_controls_tick(pad);
}
static int app_main(int argc,char**argv,char**environ){setbuf(stdout,NULL);setbuf(stderr,NULL);getcwd(root,sizeof(root));snprintf(save,sizeof(save),"%s/userdata",root);snprintf(obb,sizeof(obb),"%s/obb/main.136.com.ea.game.fifa14_row.obb",root);setenv("MASSEFFECT_SAVEDIR",save,1);setenv("SDL_NO_SIGNAL_HANDLERS","1",1);
stack_t alt={.ss_sp=malloc(65536),.ss_size=65536};sigaltstack(&alt,NULL);struct sigaction sa={0};sa.sa_flags=SA_SIGINFO|SA_ONSTACK;sa.sa_sigaction=crash;sigaction(SIGSEGV,&sa,NULL);sigaction(SIGABRT,&sa,NULL);sigaction(SIGBUS,&sa,NULL);
patch_host(host_base+HOST_after,after);patch_host(host_base+HOST_fix_path,fix_path);void(*io_root)(const char*)=(void*)(host_base+HOST_io_root);io_root(root);
DynLibFunction**tables=(void*)(host_base+HOST_tables);DynLibFunction*first=tables[0];dt_numeric_imports();fifa14_wide_imports();dt_add("statfs",fifa14_android_statfs);dt_add("eglGetCurrentDisplay",egl_current_display);dt_add("glGetString",driver_string);for(const char**n=native_imports;*n;n++)if(!find(tables,*n)&&strncmp(*n,"_Z",2)&&strncmp(*n,"gl",2)&&strncmp(*n,"egl",3)){void*p=dlsym(RTLD_DEFAULT,*n);if(p)dt_add(*n,p);}refresh(tables,first);
const char*driver=getenv("SDL_VIDEO_EGL_DRIVER");if(!dlopen(driver?driver:"libEGL.so.1",RTLD_NOW|RTLD_GLOBAL)){fprintf(stderr,"[fifa14] EGL unavailable %s\n",dlerror());return 32;}
int(*init)(unsigned)=dlsym(RTLD_DEFAULT,"SDL_Init");int(*attr)(int,int)=dlsym(RTLD_DEFAULT,"SDL_GL_SetAttribute");void*(*window)(const char*,int,int,int,int,unsigned)=dlsym(RTLD_DEFAULT,"SDL_CreateWindow");void*(*context)(void*)=dlsym(RTLD_DEFAULT,"SDL_GL_CreateContext");if(init(0x20|0x10|0x2000|1))return 33;attr(21,4);attr(17,3);attr(18,0);attr(6,24);attr(7,8);void*w=window("FIFA 14",0,0,640,480,2|0x20|0x80);void*ctx=context(w);if(!ctx)return 34;
void(*egl_init)(void*,void*)=(void*)(host_base+HOST_egl_init);egl_init(w,ctx);void(*gl1)(void)=(void*)(host_base+HOST_gles1);void(*gl2)(void)=(void*)(host_base+HOST_gles2);gl1();gl2();DynLibFunction*gles=(void*)(host_base+HOST_gles2_table);for(unsigned i=0;gles[i].symbol;i++)dt_add(gles[i].symbol,(void*)gles[i].func);refresh(tables,first);java_init();void(*options)(const char*,const char*)=(void*)(host_base+HOST_options);options(NULL,"native");
so_module*stl=load("libgnustl_shared.so");if(!stl)return 35;for(int i=0;i<stl->num_dynsym;i++){Elf_Sym*s=stl->dynsym+i;const char*n=stl->dynstr+s->st_name;if(s->st_shndx!=SHN_UNDEF&&s->st_value&&(!strncmp(n,"_Z",2)||!strncmp(n,"__cxa",5)))dt_add(n,(void*)symbol(stl,n));}refresh(tables,first);builtin_loaded("libandroid.so","libgnustl_shared.so");
so_module*nimble=load("libnimble.so");if(!nimble)return 36;builtin_loaded("libOpenSLES.so","libnimble.so");game=load("libFIFA14.so");if(!game)return 37;*(so_module**)(host_base+HOST_module)=game;fifa14_wide_init(game->text_base);
int ABI_ATTR(*onload)(JavaVM*,void*)=(void*)symbol(nimble,"JNI_OnLoad");if(onload)fprintf(stderr,"[fifa14/boot] nimble JNI=%x\n",onload(vm,NULL));onload=(void*)entry("JNI_OnLoad");if(onload)fprintf(stderr,"[fifa14/boot] FIFA JNI=%x\n",onload(vm,NULL));
invoke0("Java_com_ea_game_fifa14_Fifa14Activity_initJNI");invoke0("Java_com_ea_EAThread_EAThread_Init");
void ABI_ATTR(*eaio)(JNIEnv*,jobject,jobject,jstring,jstring,jstring)=(void*)entry("Java_com_ea_EAIO_EAIO_StartupNativeImpl");if(eaio){jstring a=original->NewStringUTF(env,save),b=original->NewStringUTF(env,root),c=original->NewStringUTF(env,obb);fprintf(stderr,"[fifa14/boot] EAIO\n");eaio(env,activity,assets,a,b,c);}
invoke0("Java_com_ea_EAMIO_StorageDirectory_StartupNativeImpl");
invoke0("Java_com_ea_EAMAudio_EAMAudioCoreWrapper_NativeStartup");
invoke0("Java_com_ea_InAppWebBrowser_BrowserAndroid_StartupNativeImpl");
invoke0("Java_com_ea_VideoPlayer_PlayerAndroid_StartupNativeImpl");
void ABI_ATTR(*rwio)(JNIEnv*,jobject,jobject,jstring,jstring)=(void*)entry("Java_com_ea_rwfilesystem_rwfilesystem_StartupNativeImpl");if(rwio){jstring a=original->NewStringUTF(env,save),b=original->NewStringUTF(env,root);fprintf(stderr,"[fifa14/boot] RenderWare filesystem\n");rwio(env,activity,assets,a,b);}
jclass ac=original->FindClass(env,"android/media/AudioTrack");jmethodID ctor=original->GetMethodID(env,ac,"<init>","(IIIIII)V");jobject track=original->NewObject(env,ac,ctor,3,44100,3,2,262144,0);void ABI_ATTR(*audio)(JNIEnv*,jobject,jobject,int,int,int,int)=(void*)entry("Java_com_ea_EAAudioCore_AndroidEAAudioCore_Init");if(audio&&track){fprintf(stderr,"[fifa14/boot] AudioTrack\n");audio(env,activity,track,262144,2,44100,0);}
invoke0("Java_com_ea_blast_MainActivity_NativeOnCreate");invoke0("Java_com_ea_blast_AndroidRenderer_NativeOnSurfaceCreated");void ABI_ATTR(*resize)(JNIEnv*,jobject,int,int)=(void*)entry("Java_com_ea_blast_AndroidRenderer_NativeOnSurfaceChanged");if(resize)resize(env,activity,640,480);invoke0("Java_com_ea_blast_MainActivity_NativeOnResume");void ABI_ATTR(*focus)(JNIEnv*,jobject,int)=(void*)entry("Java_com_ea_blast_MainActivity_NativeOnWindowFocusChanged");if(focus)focus(env,activity,1);
void ABI_ATTR(*draw)(JNIEnv*,jobject)=(void*)entry("Java_com_ea_blast_AndroidRenderer_NativeOnDrawFrame");if(!draw)return 38;
void(*swap)(void*)=dlsym(RTLD_DEFAULT,"SDL_GL_SwapWindow");int(*poll)(void*)=dlsym(RTLD_NEXT,"SDL_PollEvent");void*(*open_pad)(int)=dlsym(RTLD_DEFAULT,"SDL_GameControllerOpen");unsigned char(*button)(void*,int)=dlsym(RTLD_NEXT,"SDL_GameControllerGetButton");void*pad=open_pad(0);unsigned char event[64];unsigned long frames=0;
fifa14_controls_init(env,activity,game,host_base,1);fifa14_input_tick(NULL);while(!quit){while(poll(event))if(*(unsigned*)event==0x100)quit=1;if(pad&&button(pad,4)&&button(pad,6))quit=1;if(!access("quit.req",F_OK)){unlink("quit.req");quit=1;}if(quit)break;extern unsigned long fifa14_present_serial;unsigned long serial=fifa14_present_serial;fifa14_input_tick(pad);draw(env,activity);if(serial==fifa14_present_serial)swap(w);if(++frames<=3)fprintf(stderr,"[fifa14/frame] completed %lu\n",frames);usleep(1000);}
invoke0("Java_com_ea_blast_MainActivity_NativeOnPause");invoke0("Java_com_ea_blast_MainActivity_NativeOnStop");fflush(NULL);_exit(0);
}
int __libc_start_main(int(*mainfn)(int,char**,char**),int argc,char**argv,void(*init)(void),void(*fini)(void),void(*rtld)(void),void*stack){Dl_info d;if(!dladdr((void*)mainfn,&d))_exit(100);host_base=(uintptr_t)d.dli_fbase;int(*real)(void*,int,char**,void*,void*,void*,void*)=dlsym(RTLD_NEXT,"__libc_start_main");return real(app_main,argc,argv,init,fini,rtld,stack);}
