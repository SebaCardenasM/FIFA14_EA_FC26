from pathlib import Path
import subprocess
R=Path(__file__).resolve().parents[1];W=R.parent;T=R/'tools';C=R/'candidate';source=next((R/'research/masseffect-source').iterdir())
for n in ['numeric.c','display.c','fullscreen.c','portfps.c']:
 if not (T/n).exists():(T/n).write_text((W/'DuckTales_ArkOS/tools'/n).read_text().replace('ducktales','fifa14').replace('DUCKTALES','FIFA14'))
zig=W/'PorteadorUniversal/datos/toolchains/zig-0.13.0/zig-windows-x86_64-0.13.0/zig.exe'
subprocess.run([str(zig),'cc','-target','arm-linux-gnueabihf','-mcpu=cortex_a7','-O2','-fno-builtin','-shared','-fPIC','-Wno-incompatible-function-pointer-types','-I',str(source/'loader'),'-I',str(source/'jni'),str(T/'host.c'),str(T/'controls.c'),str(T/'storage.c'),str(T/'wide.c'),str(T/'speech.c'),str(T/'numeric.c'),str(T/'display.c'),str(T/'fullscreen.c'),str(T/'portfps.c'),'-o',str(C/'libfifa14.so'),'-ldl','-lpthread','-lm'],check=True)
print('Built FIFA ARM32 EA/JNI bootstrap with float ABI, presentation and measured FPS support')
subprocess.run([str(zig),'cc','-target','arm-linux-gnueabihf.2.28','-mcpu=cortex_a7','-O2','-fPIE','-pie',
 str(T/'intro.c'),'-L'+str(C/'runtime/lib'),'-l:libSDL2-2.0.so.0',
 '-Wl,--allow-shlib-undefined','-o',str(C/'fifa14-intro')],check=True)
print('Built ARM32 branded startup screen; full controller/display cleanup before the game')
