from pathlib import Path
import subprocess,sys,hashlib,time
R=Path(__file__).resolve().parents[1];W=R.parent;T=R/'tools';src=next((R/'research/masseffect-source').iterdir());zig=W/'PorteadorUniversal/datos/toolchains/zig-0.13.0/zig-windows-x86_64-0.13.0/zig.exe'
subprocess.run([str(zig),'cc','-target','arm-linux-gnueabihf','-mcpu=cortex_a7','-O2','-fno-builtin','-shared','-fPIC','-Wl,-Bsymbolic','-I',str(src/'loader'),'-I',str(src/'jni'),str(T/'controls.c'),str(T/'controls-live.c'),'-o',str(R/'reports/libfifa14-controls.so'),'-ldl','-lm'],check=True)
sys.path.insert(0,str(W/'SuperMombo_ArkOS/vendor'));from elftools.elf.elffile import ELFFile
with (R/'candidate/runtime/lib/libc.so.6').open('rb') as f:
 e=ELFFile(f);dl=next(s['st_value'] for s in e.get_section_by_name('.dynsym').iter_symbols() if s.name=='dlopen')
expected=hashlib.sha256((R/'reports/adapter-active-before-gameplay.so').read_bytes()).hexdigest()
sys.path.insert(0,str(W/'Blasphemous_ArkOS/tools'));from current_card_connection import connect
name='libfifa14-controls-'+time.strftime('%H%M%S')+'.so'
with connect() as c:
 _,o,e=c.exec_command('mkdir -p /roms/ports/fifa14/revisions/live-controls');o.read();assert o.channel.recv_exit_status()==0
 with c.open_sftp() as s:
  s.put(str(R/'reports/libfifa14-controls.so'),'/roms/ports/fifa14/revisions/live-controls/'+name)
  s.put(str(T/'inject-controls-device.py'),'/roms/ports/fifa14/revisions/live-controls/inject.py')
 cmd='r=$(cat /roms/ports/fifa14/latest-report); p=$(cat "$r/game.pid"); sudo -n python3 /roms/ports/fifa14/revisions/live-controls/inject.py "$p" '+expected+' '+hex(dl)+' libc.so.6 revisions/live-controls/'+name
 _,o,e=c.exec_command(cmd,timeout=20);out=o.read().decode()+e.read().decode();print(out);assert o.channel.recv_exit_status()==0,out
