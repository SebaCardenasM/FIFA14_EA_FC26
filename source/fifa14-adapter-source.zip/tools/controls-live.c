#define _GNU_SOURCE
#include <stdbool.h>
#include <link.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <sys/mman.h>
#include "so_util.h"
#include "jni.h"
#include "offsets.h"
#include "active-layout.h"
void fifa14_controls_init(JNIEnv*,jobject,so_module*,uintptr_t,int);
void fifa14_controls_tick(void*);

static void(*previous_swap)(void*);

static uintptr_t base;static int*pending,*delay;static JNIEnv*je;static jobject ja;static so_module*module;static uintptr_t core;
static int locate(struct dl_phdr_info*i,size_t n,void*p){const char*s=strrchr(i->dlpi_name,'/');if(!strcmp(s?s+1:i->dlpi_name,"libfifa14.so")){base=i->dlpi_addr;return 1;}return 0;}
static void live_tick(void*pad){fifa14_controls_tick(pad);}
__attribute__((constructor))static void install(void){
 dl_iterate_phdr(locate,NULL);if(!base)return;
 je=*(JNIEnv**)(base+ACTIVE_env);ja=*(jobject*)(base+ACTIVE_activity);module=*(so_module**)(base+ACTIVE_game);core=*(uintptr_t*)(base+ACTIVE_host_base);
 pending=(void*)(base+ACTIVE_video_pending);delay=(void*)(base+ACTIVE_video_delay);
 if(!je||!ja||!module||!core)return;
 fifa14_controls_init(je,ja,module,core,1);
 uintptr_t target=base+ACTIVE_tick;
 if(target&1){fprintf(stderr,"[fifa14/controls] live revision rejected: ARM entry required\n");return;}
 if(mprotect((void*)(target&~4095u),8192,PROT_READ|PROT_WRITE|PROT_EXEC))return;
 FILE*f=fopen("reports/controls-live-entry.bin","wb");if(f){fwrite((void*)target,1,8,f);fclose(f);}
 *(uint32_t*)target=0xe51ff004;*(uint32_t*)(target+4)=(uintptr_t)live_tick;
 __builtin___clear_cache((char*)target,(char*)target+8);
 uintptr_t swap=base+ACTIVE_swap;uint32_t*code=(void*)swap;
#ifdef PREVIOUS_NAV_SWAP
 if(code[0]==0xe51ff004){uintptr_t prior=(uintptr_t)code[1]-PREVIOUS_NAV_SWAP;previous_swap=*(void(**)(void*))(prior+PREVIOUS_SWAP_DATA);if(previous_swap&&!mprotect((void*)(swap&~4095u),4096,PROT_READ|PROT_WRITE|PROT_EXEC)){uint32_t*t=(void*)previous_swap;code[0]=t[0];code[1]=t[1];__builtin___clear_cache((char*)code,(char*)code+8);fprintf(stderr,"[fifa14/controls] original presentation restored; visual menu navigation removed\n");}}
#endif
 fprintf(stderr,"[fifa14/controls] live gamepad bridge active, entry=%p\n",(void*)target);
}
