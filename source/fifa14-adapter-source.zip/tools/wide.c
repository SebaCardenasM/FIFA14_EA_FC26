#include <stdint.h>
#include <stddef.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "platform.h"
extern void dt_add(const char*,void*);
static int ABI_ATTR(*format16)(uint16_t*,size_t,const uint16_t*,va_list);
static size_t ABI_ATTR len16(const uint16_t*s){const uint16_t*p=s;while(*p)p++;return p-s;}
static int ABI_ATTR cmp16(const uint16_t*a,const uint16_t*b){while(*a&&*a==*b){a++;b++;}return(int)*a-(int)*b;}
static uint16_t*ABI_ATTR copy16(uint16_t*d,const uint16_t*s,size_t n){uint16_t*p=d;while(n&&*s){*p++=*s++;n--;}while(n--)*p++=0;return d;}
static uint16_t*ABI_ATTR find16(const uint16_t*h,const uint16_t*n){if(!*n)return(uint16_t*)h;for(;*h;h++){const uint16_t*a=h,*b=n;while(*a&&*a==*b){a++;b++;}if(!*b)return(uint16_t*)h;}return NULL;}
static size_t ABI_ATTR to_utf8(char*out,const uint16_t*in,size_t max){size_t count=0;while(*in){uint32_t cp=*in++;if(cp>=0xd800&&cp<=0xdbff&&*in>=0xdc00&&*in<=0xdfff)cp=0x10000+((cp-0xd800)<<10)+(*in++-0xdc00);unsigned n=cp<0x80?1:cp<0x800?2:cp<0x10000?3:4;if(out&&count+n>max)return count;if(out){if(n==1)out[count]=cp;else{for(unsigned i=1;i<n;i++)out[count+n-i]=0x80|((cp>>((i-1)*6))&63);out[count]=(n==2?0xc0:n==3?0xe0:0xf0)|(cp>>((n-1)*6));}}count+=n;}if(out&&count<max)out[count]=0;return count;}
static int ABI_ATTR printf16(uint16_t*d,size_t n,const uint16_t*f,...){va_list a;va_start(a,f);int r=-1;if(format16)r=format16(d,n,f,a);else if(n)d[0]=0;va_end(a);return r;}
void fifa14_wide_imports(void){dt_add("wcslen",len16);dt_add("wcscmp",cmp16);dt_add("wcsncpy",copy16);dt_add("wcsstr",find16);dt_add("wcstombs",to_utf8);dt_add("swprintf",printf16);}
void fifa14_wide_init(uintptr_t base){
 format16=(void*)(base+0xe515bc); /* EA::StdC::Vsnprintf wchar/16 in 1.3.6 */
 static const uint16_t fmt[]={'%','s',' ','/',' ','%','s',' ',':',' ','%','d',0};
 static const uint16_t a[]={'P','r',0xf3,'x','i','m','a',0},b[]={'P','A','R','T','I','D','A',0};
 static const uint16_t expected[]={'P','r',0xf3,'x','i','m','a',' ','/',' ','P','A','R','T','I','D','A',' ',':',' ','2','7',0};
 struct{uint16_t text[64];uint32_t guard;} check={.guard=0x12345678};
 int n=printf16(check.text,64,fmt,a,b,27);
 int ok=n==22&&check.guard==0x12345678&&!memcmp(check.text,expected,sizeof(expected));
 fprintf(stderr,"[fifa14/unicode] UTF16 format, accents and bounds self-test=%s length=%d guard=%x\n",ok?"PASS":"FAIL",n,check.guard);
 if(!ok)exit(65);
}
