/* Register the supplied offline bank, using the 1.3.6 completion fields.
 * Native success callback 0x49eadc stores progress=100, selected/installed
 * locale and clears commentary mute. It does not require a second download.
 * The runtime manifest verifies these five immutable bank files at launch.
 */
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>

void fifa14_speech_tick(uintptr_t base){
 static time_t checked;static uintptr_t registered;time_t now=time(NULL);
 if(!base||now==checked||registered)return;checked=now;
 /* Exact ARM entry of the bank-success callback in our verified engine. */
 if(*(const uint32_t*)(base+0x49eadc)!=0xe92d48f0u)return;
 const char*(*directory)(void)=(void*)(base+0x33988c);
 unsigned char*(*profile_get)(void)=(void*)(base+0x63f544);
 const char*prefix=directory();unsigned char*p=profile_get();
 if(!prefix||!p||!strstr(prefix,"/userdata/Android/data/com.ea.game.fifa14_row/"))return;
 int*selected=(void*)(p+0x35a4),*installed=(void*)(p+0x35a8);
 if(*installed>=0)return;
 if(*selected<0||*selected>4)return;
 static const struct{const char*name;long long size;} files[]={
  {"hdr_ENG_US.big",332880},{"sth_ENG_US.big",373492},
  {"dat_ENG_US.bh",127984},{"pbp_ENG_US.evt",57484},
  {"dat_ENG_US.big",497643440}
 };
 for(unsigned i=0;i<sizeof(files)/sizeof(files[0]);i++){
  char path[4096];struct stat st;
  if(snprintf(path,sizeof(path),"%sSpeech/%s",prefix,files[i].name)>=(int)sizeof(path))return;
  if(stat(path,&st)||!S_ISREG(st.st_mode)||st.st_size!=files[i].size)return;
 }
 *(float*)(p+0x35a0)=100.0f;
 *installed=*selected;
 p[0x359c]=0; /* Native success callback's unmuted commentary setting. */
 registered=(uintptr_t)p;
 fprintf(stderr,"[fifa14/speech] verified local bank registered; locale=%d, progress=100, commentary unmuted\n",*selected);
}
