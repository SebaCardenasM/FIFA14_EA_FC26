"""Stage, verify and install the supplied content without replacing user saves."""
from pathlib import Path
import hashlib,json,shlex,sys,tarfile,time

R=Path(__file__).resolve().parents[1]
C=R/'candidate'
sys.path.insert(0,str(R.parent/'Blasphemous_ArkOS/tools'))
from current_card_connection import connect

plan=json.loads((R/'reports/update-transfer.json').read_text())
names=plan['files']
assert all(not n.startswith('/') and '..' not in Path(n).parts for n in names)
stamp=time.strftime('%Y%m%d-%H%M%S')
root='/roms/ports/fifa14'
stage='/roms/ports/.fifa14-update-'+stamp
backup='/roms/ports/.backups/fifa14-content-'+stamp
hashes={n:hashlib.file_digest((C/n).open('rb'),'sha256').hexdigest() for n in names}
state={'root':root,'stage':stage,'backup':backup,'hashes':hashes}
(R/'reports/last-content-install.json').write_text(json.dumps(state,indent=2))

def run(c,cmd,timeout=60):
    _,o,e=c.exec_command(cmd,timeout=timeout)
    out=o.read().decode(errors='replace')+e.read().decode(errors='replace')
    code=o.channel.recv_exit_status()
    if out:print(out,flush=True)
    assert code==0,(code,cmd)

with connect() as c:
    run(c,"! pgrep -f '(^|/| )(fifa14-host|unity6-gles3|unity-native-loader|gmloadernext.aarch64|evoland2-host)( |$)' >/dev/null")
    run(c,'test "$(df -B1 --output=avail /roms/ports | tail -n 1)" -gt '+str(plan['total']*2+100*1024*1024)+' && mkdir -p '+shlex.quote(stage)+' '+shlex.quote(backup))
    run(c,'tar -cf '+shlex.quote(backup+'/userdata-before-update.tar')+' -C '+root+' userdata')
    ch=c.get_transport().open_session();ch.settimeout(300)
    ch.exec_command('tar -xf - -C '+shlex.quote(stage))
    class Stream:
        def __init__(self):self.done=0;self.last=0;self.start=time.monotonic()
        def write(self,b):
            ch.sendall(b);self.done+=len(b)
            if self.done-self.last>=100*1024*1024:
                self.last=self.done
                print(f'{self.done/1024**2:.0f}/{plan["total"]/1024**2:.0f} MiB, {self.done/(time.monotonic()-self.start)/1024**2:.1f} MiB/s',flush=True)
            return len(b)
        def flush(self):pass
    print('Staging verified content on microSD; saves backed up.',flush=True)
    with tarfile.open(fileobj=Stream(),mode='w|') as tar:
        for n in names:
            p=C/n;info=tar.gettarinfo(str(p),n)
            info.uid=info.gid=1000;info.uname=info.gname='ark'
            info.mode=0o755 if p.suffix in ['.py','.sh'] else 0o644
            with p.open('rb') as f:tar.addfile(info,f)
    ch.shutdown_write()
    error=ch.makefile_stderr('rb').read().decode()
    assert ch.recv_exit_status()==0,error
    code=r'''
import hashlib,json,os,shutil,tarfile
from pathlib import Path
s=json.loads(CONFIG)
root,stage,backup=map(Path,[s['root'],s['stage'],s['backup']])
for name,digest in s['hashes'].items():
    with (stage/name).open('rb') as f:actual=hashlib.file_digest(f,'sha256').hexdigest()
    assert actual==digest,name
print('STAGED_FILES_SHA256_OK',len(s['hashes']),flush=True)
for name in s['hashes']:
    p=root/name;b=backup/'files'/name
    if p.exists():
        b.parent.mkdir(parents=True,exist_ok=True)
        try:os.link(p,b)
        except OSError:shutil.copy2(p,b)
for name in s['hashes']:
    p=root/name;p.parent.mkdir(parents=True,exist_ok=True)
    os.replace(stage/name,p)
    os.chown(p,1000,1000)
    if p.suffix in ['.py','.sh']:p.chmod(0o755)
(backup/'transaction.json').write_text(json.dumps(s,indent=2))
os.sync()
print('CONTENT_COMMITTED_SAVES_PRESERVED',str(backup),flush=True)
'''.replace('CONFIG',repr(json.dumps(state)))
    run(c,'python3 -c '+shlex.quote(code),300)
    run(c,'cd '+root+' && python3 verify-runtime.py >reports/content-update-integrity.log && tail -n 3 reports/content-update-integrity.log',300)
    cache="from pathlib import Path;import json,hashlib;r=Path("+repr(root)+");cache=json.loads((r/'.runtime-verified.json').read_text());(r/'.runtime-offline-verified.json').write_text(json.dumps({'schema':1,'runtime_manifest_sha256':hashlib.sha256((r/'runtime.sha256').read_bytes()).hexdigest(),'files':{n:[v[0],v[1],v[2]] for n,v in cache.items()}}))"
    run(c,'python3 -c '+shlex.quote(cache))
    with c.open_sftp() as s:
        s.put(str(R/'FIFA 14.sh'),'/roms/ports/FIFA 14.sh.updating')
        s.chmod('/roms/ports/FIFA 14.sh.updating',0o755)
        s.posix_rename('/roms/ports/FIFA 14.sh.updating','/roms/ports/FIFA 14.sh')
    run(c,'sync')
    print('UPDATE_INSTALLED_AND_FULL_RUNTIME_VERIFIED; Ports launcher installed.',flush=True)
