"""Compact the supplied EB archive, preserving every selected resource byte."""
from pathlib import Path
import hashlib,json,os,shutil,struct,time,zipfile
R=Path(__file__).resolve().parents[1];C=R/'candidate'
S=Path(r'C:\Users\user\Downloads\Downloads');D=S/'data/com.ea.game.fifa14_row'
source=S/'obb/com.ea.game.fifa14_row/main.136.com.ea.game.fifa14_row.obb'
target=C/'obb/main.136.com.ea.game.fifa14_row.obb'
revision=R/'revisions'/('pre-zeol-'+time.strftime('%Y%m%d-%H%M%S'));revision.mkdir(parents=True)
for n in ['libfifa14.so','runtime.sha256','launch.sh']:
 shutil.copy2(C/n,revision/n)
os.link(target,revision/'original.obb')
records=json.loads((R/'reports/zeol-obb-index.json').read_text())
# The supplied main "Spanish" locale is byte-identical to its Portuguese one.
# Keep the actual Spanish text from the archive, while updating club names.
excluded={'data/gui/locale/SPA_ES.loc'}
audit=[];header_size=0x20000;position=header_size
with source.open('rb') as src,target.with_suffix('.preparing').open('wb') as dst:
 header=bytearray(src.read(header_size));dst.write(header)
 for row in records:
  name=row['path'];override=D/name
  use_override=override.is_file() and name not in excluded
  if use_override:stream=override.open('rb');size=override.stat().st_size;compressed=0
  else:stream=src;src.seek(row['offset']);size=row['compressed'] or row['size'];compressed=row['compressed']
  aligned=(position+15)&~15
  if aligned>position:dst.write(bytes(aligned-position))
  digest=hashlib.sha256();remaining=size
  while remaining:
   block=stream.read(min(1024*1024,remaining));assert block,(name,remaining)
   dst.write(block);digest.update(block);remaining-=len(block)
  if use_override:stream.close()
  struct.pack_into('>I',header,48+row['i']*16,aligned//16)
  if use_override:struct.pack_into('>II',header,52+row['i']*16,0,size)
  position=aligned+size
  audit.append({'path':name,'offset':aligned,'stored_size':size,'compressed':compressed,'source':'data override' if use_override else 'provided OBB','sha256':digest.hexdigest()})
 struct.pack_into('>Q',header,24,position);dst.seek(0);dst.write(header);dst.flush();os.fsync(dst.fileno())
assert position<0x7fffffff,position
# Independent read-back of every resource after its offsets were rewritten.
with target.with_suffix('.preparing').open('rb') as stream:
 for row in audit:
  stream.seek(row['offset']);remaining=row['stored_size'];digest=hashlib.sha256()
  while remaining:
   block=stream.read(min(1024*1024,remaining));assert block;digest.update(block);remaining-=len(block)
  assert digest.hexdigest()==row['sha256'],row['path']
os.replace(target.with_suffix('.preparing'),target)
content=[];package=C/'userdata/Android/data/com.ea.game.fifa14_row'
for group in ['Speech','roster']:
 for p in (D/group).rglob('*'):
  if not p.is_file():continue
  dest=package/p.relative_to(D);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest);content.append(dest.relative_to(C).as_posix())
# This loose auxiliary file has no EB entry. It is part of the supplied data.
dest=package/'ini/na/xcareer.ini';dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(D/'ini/na/xcareer.ini',dest);content.append(dest.relative_to(C).as_posix())
with zipfile.ZipFile(S/'EA FC MOD 26 BY ZEOL.apk') as apk:
 for info in apk.infolist():
  if info.filename.startswith('assets/') and not info.is_dir():
   dest=C/info.filename;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(apk.read(info))
report={'source':str(S),'revision':str(revision),'provided_obb_size':source.stat().st_size,'packed_obb_size':position,'all_resources_readback_verified':len(audit),'resources':audit,'data_files':content,'preserved_existing_saves':True,'skipped_phone_files':['Profile','compsave','scriptsave','tutorialsave','age_gate.txt','shaders/','logs/crash reports','download staging duplicate','fut personal cache'],'preserved_spanish_locale':sorted(excluded),'native_engine':'existing adapted 1.3.6; donor differs in one instruction condition only'}
(R/'reports/content-update-plan.json').write_text(json.dumps(report,indent=2))
print('Prepared and independently verified',len(audit),'resources;',source.stat().st_size,'->',position,'bytes;',len(content),'external content files; saves untouched',flush=True)
