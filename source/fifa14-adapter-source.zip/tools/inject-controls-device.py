"""One ARM32 dlopen call on the stopped FIFA main thread; restore its context."""
from pathlib import Path
import ctypes as C,os,signal,sys,time,hashlib,json
pid=int(sys.argv[1]);expected=sys.argv[2];dlopen_offset=int(sys.argv[3],16)
root=Path('/roms/ports/fifa14');proc=Path('/proc')/str(pid)
assert (proc/'cwd').resolve()==root
assert hashlib.sha256((root/'libfifa14.so').read_bytes()).hexdigest()==expected
maps=(proc/'maps').read_text().splitlines()
rows=[s.split() for s in maps if '/'+sys.argv[4] in s]
assert rows
libbase=min(int(s[0].split('-')[0],16)-int(s[2],16) for s in rows)
fn=libbase+dlopen_offset
libc=C.CDLL(None,use_errno=True);libc.ptrace.restype=C.c_long;libc.ptrace.argtypes=[C.c_uint,C.c_int,C.c_void_p,C.c_void_p]
class Iov(C.Structure):_fields_=[('base',C.c_void_p),('size',C.c_size_t)]
def trace(op,a=0,b=0):
 C.set_errno(0);r=libc.ptrace(op,pid,a,b)
 if r==-1 and C.get_errno():raise OSError(C.get_errno(),os.strerror(C.get_errno()))
 return r
def regs_get():
 r=(C.c_uint32*18)();i=Iov(C.addressof(r),C.sizeof(r));trace(0x4204,1,C.addressof(i));assert i.size==72,('Not ARM32',i.size);return r
def regs_set(r):
 i=Iov(C.addressof(r),C.sizeof(r));trace(0x4205,1,C.addressof(i))
attached=False;saved=None;mem=None;path_address=None;before=None
try:
 trace(16);attached=True;_,status=os.waitpid(pid,0);assert os.WIFSTOPPED(status)
 saved=regs_get();r=(C.c_uint32*18)(*saved)
 path=(str(root/sys.argv[5])+'\0').encode()
 path_address=(r[13]-256)&~7;mem=(proc/'mem').open('r+b',buffering=0);mem.seek(path_address);before=mem.read(len(path));assert len(before)==len(path)
 mem.seek(path_address);mem.write(path)
 r[0]=path_address;r[1]=2;r[13]=(saved[13]-512)&~7;r[14]=0;r[15]=fn&~1;r[16]=(r[16]&~32)|(32 if fn&1 else 0);r[17]=0xffffffff
 regs_set(r);trace(7)
 deadline=time.monotonic()+10
 while True:
  got,status=os.waitpid(pid,os.WNOHANG)
  if got:break
  if time.monotonic()>deadline:os.kill(pid,signal.SIGSTOP);os.waitpid(pid,0);raise RuntimeError('dlopen did not return')
  time.sleep(.01)
 assert os.WIFSTOPPED(status),status
 end=regs_get();report={'pid':pid,'stop_signal':os.WSTOPSIG(status),'return_pc':hex(end[15]),'handle':hex(end[0]),'dlopen':hex(fn)}
 (root/'reports/controls-live-injection.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
 assert os.WSTOPSIG(status)==signal.SIGSEGV and end[15]==0 and end[0],report
finally:
 if attached:
  if mem and path_address is not None and before is not None:mem.seek(path_address);mem.write(before);mem.close()
  if saved is not None:regs_set(saved)
  trace(17)
