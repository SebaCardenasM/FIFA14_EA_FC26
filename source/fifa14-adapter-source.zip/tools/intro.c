/* FIFA 14 standalone SDL2 screen: no Unity, shader compilation or game assets.
 * The controller is closed before Unity opens it, and only one profile lives
 * in the game process. Repaint the standalone menu after the frontend handoff;
 * a single software present may leave the first physical scanout black. */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <ucontext.h>
typedef struct SDL_Window SDL_Window;
typedef struct SDL_Renderer SDL_Renderer;
typedef struct SDL_GameController SDL_GameController;
typedef struct SDL_Joystick SDL_Joystick;
typedef struct {int x,y,w,h;} Rect;
typedef union {uint32_t type;uint8_t bytes[56];uint64_t align;} Event;
extern int SDL_Init(uint32_t),SDL_PollEvent(Event*),SDL_NumJoysticks(void),SDL_IsGameController(int);
extern const char *SDL_GetError(void);
extern int SDL_SetHint(const char*,const char*);
extern int SDL_setenv(const char*,const char*,int);
extern int SDL_GL_SetAttribute(int,int);
extern SDL_Window *SDL_CreateWindow(const char*,int,int,int,int,uint32_t);
extern SDL_Renderer *SDL_CreateRenderer(SDL_Window*,int,uint32_t);
extern int SDL_RenderSetLogicalSize(SDL_Renderer*,int,int),SDL_SetRenderDrawColor(SDL_Renderer*,uint8_t,uint8_t,uint8_t,uint8_t);
extern int SDL_RenderClear(SDL_Renderer*),SDL_RenderFillRect(SDL_Renderer*,const Rect*),SDL_RenderFillRects(SDL_Renderer*,const Rect*,int);
extern void SDL_RenderPresent(SDL_Renderer*),SDL_Delay(uint32_t),SDL_Quit(void);
extern uint32_t SDL_GetTicks(void);
extern SDL_GameController *SDL_GameControllerOpen(int);
extern void SDL_GameControllerClose(SDL_GameController*),SDL_GameControllerUpdate(void);
extern uint8_t SDL_GameControllerGetButton(SDL_GameController*,int);
extern int16_t SDL_GameControllerGetAxis(SDL_GameController*,int);
extern SDL_Joystick *SDL_JoystickOpen(int);
extern void SDL_JoystickClose(SDL_Joystick*),SDL_JoystickUpdate(void);
extern uint8_t SDL_JoystickGetHat(SDL_Joystick*,int),SDL_JoystickGetButton(SDL_Joystick*,int);
extern int16_t SDL_JoystickGetAxis(SDL_Joystick*,int);
extern int SDL_GetRendererOutputSize(SDL_Renderer*,int*,int*),SDL_RenderReadPixels(SDL_Renderer*,const Rect*,uint32_t,void*,int);
static SDL_Renderer *renderer;
static int touch_buttons=1;
static const uint8_t letters[26][7]={
 {14,17,17,31,17,17,17},{30,17,17,30,17,17,30},{14,17,16,16,16,17,14},
 {30,17,17,17,17,17,30},{31,16,16,30,16,16,31},{31,16,16,30,16,16,16},
 {14,17,16,23,17,17,15},{17,17,17,31,17,17,17},{14,4,4,4,4,4,14},
 {7,2,2,2,18,18,12},{17,18,20,24,20,18,17},{16,16,16,16,16,16,31},
 {17,27,21,21,17,17,17},{17,25,21,19,17,17,17},{14,17,17,17,17,17,14},
 {30,17,17,30,16,16,16},{14,17,17,17,21,18,13},{30,17,17,30,20,18,17},
 {15,16,16,14,1,1,30},{31,4,4,4,4,4,4},{17,17,17,17,17,17,14},
 {17,17,17,17,17,10,4},{17,17,17,21,21,21,10},{17,17,10,4,10,17,17},
 {17,17,10,4,4,4,4},{31,1,2,4,8,16,31}};
static const uint8_t numbers[10][7]={
 {14,17,19,21,25,17,14},{4,12,4,4,4,4,14},{14,17,1,2,4,8,31},
 {30,1,1,14,1,1,30},{2,6,10,18,31,2,2},{31,16,16,30,1,1,30},
 {14,16,16,30,17,17,14},{31,1,2,4,8,8,8},{14,17,17,14,17,17,14},
 {14,17,17,15,1,1,14}};
static const uint8_t colon[7]={0,4,4,0,4,4,0},slash[7]={1,2,2,4,8,8,16},blank[7]={0};
static void text(const char *s,int x,int y,int scale,uint8_t r,uint8_t g,uint8_t b){
 Rect pixels[4096];int n=0;SDL_SetRenderDrawColor(renderer,r,g,b,255);
 for(int c=0;s[c];c++){
  const uint8_t *v=s[c]>='A'&&s[c]<='Z'?letters[s[c]-'A']:s[c]>='0'&&s[c]<='9'?numbers[s[c]-'0']:s[c]==':'?colon:s[c]=='/'?slash:blank;
  for(int row=0;row<7;row++)for(int col=0;col<5;col++)if(v[row]&(1<<(4-col))){
   pixels[n++]=(Rect){x+(c*6+col)*scale,y+row*scale,scale,scale};
   if(n==4096){SDL_RenderFillRects(renderer,pixels,n);n=0;}
  }
 }
 if(n)SDL_RenderFillRects(renderer,pixels,n);
}
static void center(const char*s,int y,int scale,int r,int g,int b){text(s,(640-(int)strlen(s)*6*scale)/2,y,scale,r,g,b);}

static void screen(void){
 SDL_SetRenderDrawColor(renderer,13,17,25,255);SDL_RenderClear(renderer);
 center("PORT HECHO POR DANI",24,2,165,182,203);
 center("FIFA 14",65,5,246,204,99);
 center("MOD FC 26",118,3,235,238,242);
 center("ELIGE LOS CONTROLES",161,2,173,195,214);
 const char *labels[]={"CON BOTONES TACTILES","SIN BOTONES TACTILES"};
 for(int i=0;i<2;i++){
  Rect panel={70,196+i*61,500,49};
  if(touch_buttons==(i==0))SDL_SetRenderDrawColor(renderer,43,100,117,255);
  else SDL_SetRenderDrawColor(renderer,29,38,51,255);
  SDL_RenderFillRect(renderer,&panel);center(labels[i],212+i*61,2,255,255,255);
 }
 center("SIN TACTILES PUEDE PRESENTAR ERRORES",330,2,255,198,117);
 center("L3: CURSOR   R3: MOSTRAR FPS",377,2,173,195,214);
 center("CRUCETA / JOYSTICK: CAMBIAR",404,2,235,238,242);
 center("A / B / START: CONFIRMAR",431,2,235,238,242);
 center("SELECT: VOLVER A PORTS",459,2,185,198,211);
 static int captured=-1;
 const char *capture=getenv("FIFA14_INTRO_CAPTURE");
 if(capture&&captured!=touch_buttons){int w=0,h=0;if(!SDL_GetRendererOutputSize(renderer,&w,&h)&&w>0&&h>0&&w<=4096&&h<=4096){
  uint32_t*pixels=malloc((size_t)w*h*4);
  if(pixels&&!SDL_RenderReadPixels(renderer,NULL,0x16362004,pixels,w*4)){
   FILE*f=fopen(capture,"wb");if(f){fprintf(f,"P6\n%d %d\n255\n",w,h);for(int i=0;i<w*h;i++){uint8_t b[]={pixels[i]>>16,pixels[i]>>8,pixels[i]};fwrite(b,1,3,f);}fclose(f);}
  }free(pixels);captured=touch_buttons;
 }}
 SDL_RenderPresent(renderer);
}
extern void SDL_DestroyRenderer(SDL_Renderer*),SDL_DestroyWindow(SDL_Window*);
static void crash(int sig,siginfo_t*info,void*context){
 ucontext_t*u=context;
 fprintf(stderr,"[fifa14/intro-crash] signal=%d fault=%p pc=%lx lr=%lx\n",sig,info->si_addr,(unsigned long)u->uc_mcontext.arm_pc,(unsigned long)u->uc_mcontext.arm_lr);
 fflush(stderr);_Exit(128+sig);
}
int main(int argc,char **argv){
 const char *choicefile=argc>1?argv[1]:"touch-controls.choice";
 int preview=argc>2&&(!strcmp(argv[2],"--preview-with")||!strcmp(argv[2],"--preview-without"));
 if(preview){touch_buttons=!strcmp(argv[2],"--preview-with");SDL_setenv("SDL_VIDEODRIVER","dummy",1);}
 setbuf(stderr,NULL);struct sigaction action={0};action.sa_flags=SA_SIGINFO;action.sa_sigaction=crash;sigaction(SIGSEGV,&action,NULL);sigaction(SIGABRT,&action,NULL);
 fprintf(stderr,"[fifa14/intro] initializing native ARM32 SDL\n");
 if(SDL_Init(preview?0x20:0x20|0x2000|0x200|0x4000)){fprintf(stderr,"[fifa14/intro] SDL: %s\n",SDL_GetError());return 2;}
 fprintf(stderr,"[fifa14/intro] SDL initialized\n");
 SDL_GL_SetAttribute(21,4);SDL_GL_SetAttribute(17,3);SDL_GL_SetAttribute(18,0);
 SDL_SetHint("SDL_RENDER_DRIVER",preview?"software":"opengles2");
 SDL_Window*window=SDL_CreateWindow("FIFA 14 MOD FC 26 - Dani",0,0,640,480,preview?8:0x1003);
 fprintf(stderr,"[fifa14/intro] window=%p\n",window);
 renderer=window?SDL_CreateRenderer(window,-1,preview?1:6):NULL;
 fprintf(stderr,"[fifa14/intro] renderer=%p\n",renderer);
 const char*backend="opengles2";
 if(window&&!renderer){SDL_SetHint("SDL_RENDER_DRIVER","software");renderer=SDL_CreateRenderer(window,-1,1);backend="software";}
 if(!renderer){fprintf(stderr,"[fifa14/intro] video: %s\n",SDL_GetError());if(window)SDL_DestroyWindow(window);SDL_Quit();return 2;}
 SDL_RenderSetLogicalSize(renderer,640,480);
 if(preview){screen();SDL_DestroyRenderer(renderer);SDL_DestroyWindow(window);SDL_Quit();return 0;}
 SDL_GameController*pad=NULL;SDL_Joystick*joy=NULL;
 for(int i=0;i<SDL_NumJoysticks();i++)if(SDL_IsGameController(i)&&(pad=SDL_GameControllerOpen(i)))break;
 if(!pad&&SDL_NumJoysticks())joy=SDL_JoystickOpen(0);
 int previous=0,previous_dir=0,armed=0,result=125;uint32_t began=SDL_GetTicks(),lastdraw=began;screen();
 fprintf(stderr,"[fifa14/intro] ready backend=%s repaint=100ms; game clocks not applied yet\n",backend);
 for(;;){
  Event e;int confirm=0,cancel=0,redraw=0,move=0;
  while(SDL_PollEvent(&e)){
   if(e.type==0x100)cancel=1;
   if(e.type==0x200||e.type==0x2000||e.type==0x2001)redraw=1;
   if(e.type==0x300){int key;memcpy(&key,e.bytes+20,4);if(key==27)cancel=1;if(key==13||key==32)confirm=1;
    if(!e.bytes[13]&&(key==1073741906||key==1073741905||key==1073741904||key==1073741903))move=1;
   }
  }
  int buttons=0,dir=0;
  if(pad){SDL_GameControllerUpdate();buttons=(SDL_GameControllerGetButton(pad,0)||SDL_GameControllerGetButton(pad,1)||SDL_GameControllerGetButton(pad,6))?1:0;if(SDL_GameControllerGetButton(pad,4))buttons|=2;
   dir=SDL_GameControllerGetButton(pad,11)||SDL_GameControllerGetButton(pad,12)||SDL_GameControllerGetButton(pad,13)||SDL_GameControllerGetButton(pad,14)||abs(SDL_GameControllerGetAxis(pad,0))>16000||abs(SDL_GameControllerGetAxis(pad,1))>16000;
  }
  else if(joy){SDL_JoystickUpdate();buttons=(SDL_JoystickGetButton(joy,0)||SDL_JoystickGetButton(joy,1)||SDL_JoystickGetButton(joy,7))?1:0;if(SDL_JoystickGetButton(joy,6))buttons|=2;
   dir=SDL_JoystickGetHat(joy,0)||abs(SDL_JoystickGetAxis(joy,0))>16000||abs(SDL_JoystickGetAxis(joy,1))>16000;
  }
  uint32_t now=SDL_GetTicks();if(!buttons&&now-began>300)armed=1;
  if(armed){if((buttons&1)&&!(previous&1))confirm=1;if((buttons&2)&&!(previous&2))cancel=1;}
  if(armed&&(move||(dir&&!previous_dir))){touch_buttons=!touch_buttons;redraw=1;}
  if(cancel)break;
  if(confirm&&armed){
   char next[4096];if(snprintf(next,sizeof(next),"%s.next",choicefile)>=(int)sizeof(next)){result=2;break;}
   FILE*f=fopen(next,"w");if(!f){result=2;break;}
   fprintf(f,"%d\n",touch_buttons);int ok=fclose(f)==0;
   if(!ok||rename(next,choicefile)){remove(next);result=2;break;}
   fprintf(stderr,"[fifa14/intro] touch_buttons=%d\n",touch_buttons);result=0;break;
  }
  if(redraw||now-lastdraw>=100){screen();lastdraw=now;}
  previous=buttons;previous_dir=dir;SDL_Delay(12);
 }
 if(pad)SDL_GameControllerClose(pad);if(joy)SDL_JoystickClose(joy);
 SDL_DestroyRenderer(renderer);SDL_DestroyWindow(window);SDL_Quit();
 fprintf(stderr,"[fifa14/intro] result=%s; controller and display released\n",result==0?"start":"cancel");return result;
}
