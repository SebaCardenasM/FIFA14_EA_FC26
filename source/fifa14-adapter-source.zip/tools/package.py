from pathlib import Path
import hashlib,json,os,stat,time,zipfile
R=Path(__file__).resolve().parents[1];C=R/'candidate'
out=R/'dist/FIFA14_EA_FC26_COMPLETO_R36.zip';out.parent.mkdir(exist_ok=True)
def release_file(p):
 if not p.is_file():return False
 rel=p.relative_to(C).as_posix();parts=p.relative_to(C).parts
 if any(n in {'reports','revisions','.backups','__pycache__','shaders'} for n in parts):return False
 if parts[0]=='userdata':return (rel.startswith('userdata/Android/data/com.ea.game.fifa14_row/Speech/') and p.suffix in {'.big','.bh','.evt'}) or rel.endswith('/roster/console_cl.bin')
 if p.name.startswith('.') or p.name in {'latest-report','fps-overlay.cfg','capture.ppm','capture.req','quit.req','controls.req','input.req'} or p.suffix in {'.log','.pyc'}:return False
 return True
files=[(R/'FIFA 14.sh','FIFA 14.sh')]+[(p,'fifa14/'+p.relative_to(C).as_posix()) for p in sorted(C.rglob('*')) if release_file(p)]
manifest={line.split(None,1)[1].strip():line.split(None,1)[0] for line in (C/'runtime.sha256').read_text().splitlines()}
for name,digest in manifest.items():
    with (C/name).open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==digest,name
total=sum(p.stat().st_size for p,n in files);done=0
temporary=out.with_suffix('.zip.preparing')
with zipfile.ZipFile(temporary,'w',zipfile.ZIP_DEFLATED,compresslevel=1,allowZip64=True) as z:
    for p,name in files:
        info=zipfile.ZipInfo(name,time.localtime(p.stat().st_mtime)[:6]);info.create_system=3
        info.compress_type=zipfile.ZIP_DEFLATED;info._compresslevel=1
        executable=p.suffix in ['.sh','.py'] or p.name in {'fifa14-host','fifa14-intro'} or name.startswith('fifa14/runtime/')
        info.external_attr=(stat.S_IFREG|(0o755 if executable else 0o644))<<16
        with p.open('rb') as src,z.open(info,'w',force_zip64=True) as dst:
            for b in iter(lambda:src.read(1024*1024),b''):dst.write(b)
        done+=p.stat().st_size
        if p.stat().st_size>100000000:print(f'Packed {done/1024**2:.0f}/{total/1024**2:.0f} MiB',flush=True)
print('Checking every ZIP entry CRC...',flush=True)
with zipfile.ZipFile(temporary) as z:
    assert len(z.namelist())==len(set(z.namelist()))==len(files)
    assert z.testzip() is None
    for n in ['FIFA 14.sh','fifa14/libfifa14.so','fifa14/runtime/ld-linux-armhf.so.3','fifa14/obb/main.136.com.ea.game.fifa14_row.obb','fifa14/userdata/Android/data/com.ea.game.fifa14_row/Speech/dat_ENG_US.big']:
        assert n in z.namelist(),n
os.replace(temporary,out)
with out.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
out.with_suffix('.zip.sha256').write_text(digest+'  '+out.name+'\n',encoding='ascii')
report={'path':str(out),'files':len(files),'size':out.stat().st_size,'extracted_size':total,'sha256':digest,'all_entries_crc_ok':True,'runtime_sha256_ok':True}
(R/'reports/package-final.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2),flush=True)
