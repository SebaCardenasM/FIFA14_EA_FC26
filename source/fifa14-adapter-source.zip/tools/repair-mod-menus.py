"""Restore proven navigation while retaining the supplied mod's game content."""
from pathlib import Path
import base64,hashlib,json,os,shlex,sys,time,xml.etree.ElementTree as ET
R=Path(__file__).resolve().parents[1];C=R/'candidate'
name='obb/main.136.com.ea.game.fifa14_row.obb';obb=C/name
rows={r['path']:r for r in json.loads((R/'reports/content-update-plan.json').read_text())['resources']}
selected=['Home_Android.xml','Play_unlocked_Android.xml','Play_locked_Android.xml','Customize.xml','Help.xml']
patches=[]
with obb.open('rb') as f:
    before_digest=hashlib.file_digest(f,'sha256').hexdigest()
    for leaf in selected:
        path='data/gui/data/xml/ScreensLayouts/MainMenu/'+leaf;r=rows[path]
        data=(R/'research/original-menu'/leaf).read_bytes()
        tree=ET.fromstring(data)
        if leaf=='Play_unlocked_Android.xml':assert tree.find('.//tile[@id="ManagerMode"]') is not None
        if leaf=='Customize.xml':assert tree.find('.//tile[@id="Controls"]') is not None
        assert not r['compressed'] and len(data)==r['stored_size']
        f.seek(r['offset']);old=f.read(len(data));assert hashlib.sha256(old).hexdigest()==r['sha256']
        patches.append({'path':path,'offset':r['offset'],'before':base64.b64encode(old).decode(),'after':base64.b64encode(data).decode()})
revision=R/'revisions'/('menu-correction-'+time.strftime('%Y%m%d-%H%M%S'));revision.mkdir()
(revision/'ranges.json').write_text(json.dumps(patches,indent=2))
with obb.open('r+b') as f:
    for p in patches:f.seek(p['offset']);f.write(base64.b64decode(p['after']))
    f.flush();os.fsync(f.fileno())
with obb.open('rb') as f:after_digest=hashlib.file_digest(f,'sha256').hexdigest()
plan={'name':name,'old_sha256':before_digest,'new_sha256':after_digest,'patches':patches}
(R/'reports/menu-correction.json').write_text(json.dumps(plan,indent=2))
sys.path.insert(0,str(R.parent/'Blasphemous_ArkOS/tools'))
from current_card_connection import connect
with connect() as c:
    def run(cmd):
        _,o,e=c.exec_command(cmd,timeout=40);out=o.read().decode()+e.read().decode();print(out,flush=True);assert o.channel.recv_exit_status()==0
    run("! pgrep -f '(^|/| )fifa14-host( |$)' >/dev/null")
    code=r'''
import base64,hashlib,json,os,time
from pathlib import Path
root=Path('/roms/ports/fifa14');s=json.loads(CONFIG);path=root/s['name']
cache=json.loads((root/'.runtime-verified.json').read_text());st=path.stat()
# The complete file was hashed after transfer. Require the same inode and
# timestamps before applying bounded replacements, and verify both sides.
assert cache[s['name']]==[s['old_sha256'],st.st_size,st.st_mtime_ns,st.st_ctime_ns,st.st_ino]
with path.open('rb') as f:
 for p in s['patches']:
  f.seek(p['offset']);assert f.read(len(base64.b64decode(p['before'])))==base64.b64decode(p['before'])
backup=root.parent/'.backups'/('fifa14-menu-'+time.strftime('%Y%m%d-%H%M%S'));backup.mkdir()
(backup/'ranges.json').write_text(json.dumps(s,indent=2))
with path.open('r+b') as f:
 for p in s['patches']:f.seek(p['offset']);f.write(base64.b64decode(p['after']))
 f.flush();os.fsync(f.fileno())
with path.open('rb') as f:
 for p in s['patches']:
  f.seek(p['offset']);assert f.read(len(base64.b64decode(p['after'])))==base64.b64decode(p['after'])
st=path.stat();cache[s['name']]=[s['new_sha256'],st.st_size,st.st_mtime_ns,st.st_ctime_ns,st.st_ino]
temp=root/'.runtime-verified.menu.tmp';temp.write_text(json.dumps(cache));os.replace(temp,root/'.runtime-verified.json')
print('VERIFIED_5_MENU_RANGES; full prior file identity matched; data and saves retained')
'''.replace('CONFIG',repr(json.dumps(plan)))
    run('python3 -c '+shlex.quote(code))
print('Local and SD menu repairs match; regenerate runtime manifest before launching.')
