#define _GNU_SOURCE
#include <dlfcn.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>

/* Shader-free EGL overlay. Only framebuffer, scissor, clear colour and colour
 * mask are changed, and each is restored before the application's next frame.
 * No game logic, controller hooks, textures, shaders or vertex state change. */
static void *(*lookup)(void *,const char *);
static void *(*get_proc)(const char *);
static void *egl_library;
static unsigned (*next_swap)(void *,void *);
static unsigned (*query_surface)(void *,void *,int,int *);
static void (*get_int)(unsigned,int *),(*get_float)(unsigned,float *),(*get_bool)(unsigned,unsigned char *);
static unsigned char (*is_enabled)(unsigned);
static const unsigned char *(*get_string)(unsigned);
static void (*enable)(unsigned),(*disable)(unsigned),(*clear)(unsigned);
static void (*scissor)(int,int,int,int),(*clear_color)(float,float,float,float);
static void (*color_mask)(unsigned char,unsigned char,unsigned char,unsigned char);
static void (*bind_fbo)(unsigned,unsigned);
static double window_start,shown_fps,last_present,largest_gap;
static unsigned window_frames,slow_frames;
static _Thread_local unsigned direct_present_depth;
static int api_ready,fps_valid,draw_target=0x8D40;
static double clock_now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec/1e9;}
static int hud_enabled(void){const char *value=getenv("PORT_FPS_HUD");return value&&strcmp(value,"0");}
static void record_present(unsigned result) {
    if(!result)return;
    double now=clock_now();
    if(!window_start)window_start=now;
    if(last_present){double gap=now-last_present;if(gap>largest_gap)largest_gap=gap;if(gap>.1)slow_frames++;}
    last_present=now;
    ++window_frames;
    if(now-window_start>=1){double elapsed=now-window_start;shown_fps=window_frames/elapsed;window_start=now;window_frames=0;fps_valid=1;fprintf(stderr,"[fifa14/fps] measured=%.2f interval_s=%.3f max_gap=%.3f slow=%u\n",shown_fps,elapsed,largest_gap,slow_frames);largest_gap=0;slow_frames=0;}
}

static void resolve_lookup(void) {
    if (lookup) return;
#if defined(__aarch64__)
    const char *version="GLIBC_2.17";
#else
    const char *version="GLIBC_2.4";
#endif
    void *(*base)(void *,const char *)=dlvsym(RTLD_NEXT,"dlsym",version);
    if (!base) return;
    /* Respect any existing compatibility interposer after this library. */
    lookup=base(RTLD_NEXT,"dlsym");
    if (!lookup) lookup=base;
}
static void *resolve(const char *name) {
    void *p=get_proc ? get_proc(name) : 0;
    if(p)return p;
    p=lookup&&egl_library ? lookup(egl_library,name) : 0;
    return p ? p : (lookup ? lookup(RTLD_DEFAULT,name) : 0);
}
static int load_api(void) {
    if (api_ready) return api_ready>0;
    resolve_lookup();
    if (!get_proc && lookup) get_proc=lookup(RTLD_NEXT,"eglGetProcAddress");
    if (!get_proc && lookup) {egl_library=dlopen("libEGL.so.1",RTLD_LAZY|RTLD_LOCAL);if(egl_library)get_proc=lookup(egl_library,"eglGetProcAddress");}
    query_surface=resolve("eglQuerySurface");
    get_int=resolve("glGetIntegerv");get_float=resolve("glGetFloatv");get_bool=resolve("glGetBooleanv");
    is_enabled=resolve("glIsEnabled");get_string=resolve("glGetString");
    enable=resolve("glEnable");disable=resolve("glDisable");scissor=resolve("glScissor");
    clear_color=resolve("glClearColor");color_mask=resolve("glColorMask");clear=resolve("glClear");bind_fbo=resolve("glBindFramebuffer");
    if (!query_surface||!get_int||!get_float||!get_bool||!is_enabled||!get_string||!enable||!disable||!scissor||!clear_color||!color_mask||!clear||!bind_fbo) return 0;
    const char *version=(const char *)get_string(0x1F02);
    if (!version) return 0;
    if (strstr(version,"OpenGL ES 3")) draw_target=0x8CA9;
    api_ready=1;
    return 1;
}
static const unsigned char digits[10][7]={
 {14,17,19,21,25,17,14},{4,12,4,4,4,4,14},{14,17,1,2,4,8,31},
 {30,1,1,14,1,1,30},{2,6,10,18,31,2,2},{31,16,16,30,1,1,30},
 {14,16,16,30,17,17,14},{31,1,2,4,8,8,8},{14,17,17,14,17,17,14},
 {14,17,17,15,1,1,14}};
static const unsigned char F[7]={31,16,16,30,16,16,16},P[7]={30,17,17,30,16,16,16},S[7]={15,16,16,14,1,1,30},dot[7]={0,0,0,0,0,6,6},empty[7]={0};
static const unsigned char *glyph(char c) {
    if(c>='0'&&c<='9') return digits[c-'0'];
    if(c=='F')return F;if(c=='P')return P;if(c=='S')return S;if(c=='.')return dot;return empty;
}
static int draw_overlay(int width,int height) {
    if (!load_api()||width<120||height<40) return 0;
    int old_fbo,old_scissor[4];float old_color[4];unsigned char old_mask[4];
    unsigned char had_scissor=is_enabled(0x0C11);
    get_int(0x8CA6,&old_fbo);get_int(0x0C10,old_scissor);get_float(0x0C22,old_color);get_bool(0x0C23,old_mask);
    bind_fbo(draw_target,0);enable(0x0C11);color_mask(1,1,1,1);
    char text[24];if(fps_valid)snprintf(text,sizeof(text),"FPS %.1f",shown_fps);else snprintf(text,sizeof(text),"FPS ...");
    size_t count=strlen(text);if(count>12)count=12;
    int scale=2,box_w=(int)count*6*scale+8,box_h=7*scale+8;
    int x=width-box_w-6,y=height-box_h-6;
    clear_color(0.02f,0.02f,0.03f,1);scissor(x,y,box_w,box_h);clear(0x4000);
    clear_color(0.5f,1.0f,0.56f,1);
    for(size_t c=0;c<count;++c)for(int row=0;row<7;++row){
        const unsigned char *g=glyph(text[c]);int col=0;
        while(col<5){if(!(g[row]&(1<<(4-col)))){++col;continue;}
            int first=col;while(col<5&&(g[row]&(1<<(4-col))))++col;
            scissor(x+4+(int)c*6*scale+first*scale,y+4+(6-row)*scale,(col-first)*scale,scale);clear(0x4000);
        }
    }
    clear_color(old_color[0],old_color[1],old_color[2],old_color[3]);color_mask(old_mask[0],old_mask[1],old_mask[2],old_mask[3]);
    scissor(old_scissor[0],old_scissor[1],old_scissor[2],old_scissor[3]);if(!had_scissor)disable(0x0C11);bind_fbo(draw_target,(unsigned)old_fbo);
    return 1;
}
int portfps_self_test(int width,int height) {
    if (!load_api())return -1;
    int fbo_a,fbo_b,sc_a[4],sc_b[4];float c_a[4],c_b[4];unsigned char m_a[4],m_b[4];
    unsigned char enabled_a=is_enabled(0x0C11);
    get_int(0x8CA6,&fbo_a);get_int(0x0C10,sc_a);get_float(0x0C22,c_a);get_bool(0x0C23,m_a);
    if(!draw_overlay(width,height))return -2;
    get_int(0x8CA6,&fbo_b);get_int(0x0C10,sc_b);get_float(0x0C22,c_b);get_bool(0x0C23,m_b);
    return fbo_a==fbo_b&&enabled_a==is_enabled(0x0C11)&&!memcmp(sc_a,sc_b,sizeof(sc_a))&&!memcmp(c_a,c_b,sizeof(c_a))&&!memcmp(m_a,m_b,sizeof(m_a)) ? 1 : -3;
}
#ifndef PORTFPS_DIRECT_ONLY
static unsigned present(void *display,void *surface) {
    if (!next_swap){resolve_lookup();next_swap=lookup ? lookup(RTLD_NEXT,"eglSwapBuffers") : 0;}
    if (!next_swap)return 0;
    if (!direct_present_depth && hud_enabled()) {
        if(load_api()) {int w=0,h=0;if(query_surface(display,surface,0x3057,&w)&&query_surface(display,surface,0x3056,&h))draw_overlay(w,h);}
    }
    unsigned result=next_swap(display,surface);
    if(!direct_present_depth)record_present(result);
    return result;
}
#endif
/* Java EGL can submit to the compositor or call host EGL directly. Suppress
 * the nested wrapper so each successful Java presentation is counted once. */
__attribute__((visibility("default"))) void portfps_present_begin(int width,int height) {
    if(!direct_present_depth++ && hud_enabled())draw_overlay(width,height);
}
__attribute__((visibility("default"))) void portfps_present_end(int result) {
    if(direct_present_depth && !--direct_present_depth)record_present(result!=0);
}
#ifndef PORTFPS_DIRECT_ONLY
unsigned eglSwapBuffers(void *display,void *surface){return present(display,surface);}
static void *wrap(const char *name,void *p) {if(p&&!strcmp(name,"eglSwapBuffers")&&p!=(void *)present&&p!=(void *)eglSwapBuffers){next_swap=p;return present;}return p;}
static void *proc_wrap(const char *name){return wrap(name,get_proc(name));}
void *dlsym(void *handle,const char *name) {
    resolve_lookup();if(!lookup)return 0;
    void *p=lookup(handle,name);
    if(p&&!strcmp(name,"eglGetProcAddress")&&p!=(void *)proc_wrap){get_proc=p;return proc_wrap;}
    return wrap(name,p);
}
#endif
