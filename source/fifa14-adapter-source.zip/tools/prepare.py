from pathlib import Path
import zipfile,hashlib,shutil,json,sys,struct
R=Path(__file__).resolve().parents[1];W=R.parent;C=R/'candidate'
apk=Path(r'C:\Users\user\Downloads\FIFA 14\FIFA14-v1.3.6-by-Sr-Gabo.apk')
for name in ['native','assets','obb','userdata','reports','source','license','cache']:(C/name).mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(W/'SuperMombo_ArkOS/vendor'))
from elftools.elf.elffile import ELFFile
with zipfile.ZipFile(apk) as z:
 for info in z.infolist():
  n=info.filename
  if n.startswith('assets/apkvision/files/obb/'):
   out=C/'obb'/Path(n).name
  elif n.startswith('assets/apkvision/files/') and n.endswith('.so'):
   out=C/'native'/Path(n).name
  elif n.startswith('assets/') and not n.startswith(('assets/apkvision/','assets/7d6e/')) and not info.is_dir():
   out=C/n
  else:continue
  if out.exists() and out.stat().st_size==info.file_size:continue
  out.parent.mkdir(parents=True,exist_ok=True)
  with z.open(info) as src,out.open('wb') as dst:shutil.copyfileobj(src,dst,1024*1024)
  print('Extracted',out.relative_to(C),out.stat().st_size,flush=True)
# Normalize only NDK build-machine paths in DT_NEEDED; retain original code/data.
patches=[]
for p in (C/'native').glob('*.so'):
 data=bytearray(p.read_bytes())
 with p.open('rb') as f:
  e=ELFFile(f);dyn=e.get_section_by_name('.dynamic');strings=e.get_section(dyn['sh_link'])
  for i,t in enumerate(dyn.iter_tags()):
   if t.entry.d_tag!='DT_NEEDED' or '/' not in t.needed:continue
   offset=t.entry.d_val+t.needed.rfind('/')+1;at=dyn['sh_offset']+i*dyn['sh_entsize']+4
   struct.pack_into('<I',data,at,offset);patches.append({'file':p.name,'needed':t.needed,'normalized':t.needed.rsplit('/',1)[-1],'offset':at})
 if patches:p.write_bytes(data)
(R/'reports/needed-paths.json').write_text(json.dumps(patches,indent=2))
for n in ['runtime','graphics','compat']:
 if not (C/n).exists():shutil.copytree(W/'DuckTales_ArkOS/candidate'/n,C/n)
with zipfile.ZipFile(R/'research/masseffect-runtime.zip') as z:
 for n in ['libstdc++.so.6','libbsd.so.0','libmd.so.0']:(C/'runtime/lib'/n).write_bytes(z.read('masseffect/libs.armhf/'+n))
shutil.copy2(R/'research/ea-host',C/'fifa14-host')
for n in ['gamecontrollerdb.txt','verify-runtime.py','port_clocks.py']:shutil.copy2(W/'DuckTales_ArkOS/candidate'/n,C/n)
shutil.copy2(R/'research/masseffect-native-arm-source.zip',C/'source/ea-native-host-source.zip')
src=next((R/'research/masseffect-source').iterdir())
shutil.copy2(src/'LICENSE',C/'license/ea-native-host.txt');shutil.copy2(src/'NOTICE.md',C/'license/ea-native-host-NOTICE.md')
with (C/'fifa14-host').open('rb') as f:
 e=ELFFile(f);syms={s.name:s for s in e.get_section_by_name('.symtab').iter_symbols()}
 names={'create_vm':'JNI_CreateJavaVM','tables':'so_dynamic_libraries','load':'so_load_module','options':'so_set_options','symbol':'so_symbol','after':'so_after_relocate','module':'_ZL8g_module','io_root':'_Z15io_set_game_dirPKc','io_writable':'_Z15io_writable_dirv','get_activity':'_ZN12MainActivity11GetInstanceEP7_JNIEnvP7_jclass','get_assets':'_ZN12MainActivity9getAssetsEP7_JNIEnvP8_jobject','gles2':'_Z16load_gles2_funcsv','gles1':'_Z16load_gles1_funcsv','fix_path':'_Z8fix_pathPKcPcj','resolve':'so_resolve_link','egl_init':'android_egl_init','builtin':'so_builtin_libs','asset_fd':'_ZL4g_fd','gles2_table':'symtable_gles2'}
 missing=[n for n in names.values() if n not in syms];assert not missing,missing
 (R/'tools/offsets.h').write_text(''.join('#define HOST_'+n+' '+hex(syms[s]['st_value'])+'\n' for n,s in names.items()))
imports=set()
for p in (C/'native').glob('*.so'):
 with p.open('rb') as f:
  e=ELFFile(f);imports.update(s.name for s in e.get_section_by_name('.dynsym').iter_symbols() if s.name and s['st_shndx']=='SHN_UNDEF')
(R/'tools/imports.h').write_text('static const char*native_imports[]={\n'+''.join(json.dumps(n)+',\n' for n in sorted(imports))+'NULL};\n')
print('Prepared',sum(p.stat().st_size for p in C.rglob('*') if p.is_file()),'bytes; host and data not yet validated',flush=True)
