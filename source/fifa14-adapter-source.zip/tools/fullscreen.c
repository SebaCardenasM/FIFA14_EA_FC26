#define _GNU_SOURCE
#include <dlfcn.h>
void *fifa14_native_open(const char*,int);
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdatomic.h>
static _Atomic uint64_t content_size;
void fifa14_set_content_size(int w,int h){if(w>=160&&h>=160&&w<=1920&&h<=1920){atomic_store(&content_size,((uint64_t)(unsigned)w<<32)|(unsigned)h);fprintf(stderr,"[fifa14/display] Android content=%dx%d\n",w,h);}}
typedef struct {void *context;unsigned fbo,colour;int w,h;} Copy;
static Copy copies[16];
void fifa14_fullscreen_present(int width,int height){
 static void *driver;static void(*get)(unsigned,int*),(*bind)(unsigned,unsigned),(*blit)(int,int,int,int,int,int,int,int,unsigned,unsigned);
 static void(*gen_fbo)(int,unsigned*),(*gen_rb)(int,unsigned*),(*bind_rb)(unsigned,unsigned),(*storage)(unsigned,unsigned,int,int),(*attach)(unsigned,unsigned,unsigned,unsigned);
 static void(*delete_fbo)(int,const unsigned*),(*delete_rb)(int,const unsigned*),(*finish)(void),(*disable)(unsigned),(*enable)(unsigned);
 static unsigned(*status)(unsigned);static unsigned char(*enabled)(unsigned);static void*(*current)(void);
 static void(*get_float)(unsigned,float*),(*mask)(unsigned char,unsigned char,unsigned char,unsigned char),(*clear_colour)(float,float,float,float),(*clear)(unsigned);
 if(!driver){const char*p=getenv("SDL_VIDEO_GL_DRIVER");driver=fifa14_native_open(p?p:"libGLESv2.so.2",RTLD_NOW|RTLD_LOCAL);if(!driver)return;
#define LOAD(field,name) field=dlsym(driver,name);if(!field)return
  LOAD(get,"glGetIntegerv");LOAD(bind,"glBindFramebuffer");LOAD(blit,"glBlitFramebuffer");LOAD(gen_fbo,"glGenFramebuffers");LOAD(gen_rb,"glGenRenderbuffers");LOAD(bind_rb,"glBindRenderbuffer");LOAD(storage,"glRenderbufferStorage");LOAD(attach,"glFramebufferRenderbuffer");LOAD(status,"glCheckFramebufferStatus");LOAD(delete_fbo,"glDeleteFramebuffers");LOAD(delete_rb,"glDeleteRenderbuffers");LOAD(finish,"glFinish");LOAD(disable,"glDisable");LOAD(enable,"glEnable");LOAD(enabled,"glIsEnabled");
  current=dlsym(RTLD_NEXT,"SDL_GL_GetCurrentContext");
  LOAD(get_float,"glGetFloatv");LOAD(mask,"glColorMask");LOAD(clear_colour,"glClearColor");LOAD(clear,"glClear");
 }
 if(!current)return;void*context=current();if(!context)return;
 int viewport[4],draw,read,rb;get(0xba2,viewport);get(0x8ca6,&draw);get(0x8caa,&read);get(0x8ca7,&rb);
 uint64_t requested=atomic_load(&content_size);int w=requested?(int)(requested>>32):width,h=requested?(int)(uint32_t)requested:height;
 int sx=0,sy=0;
 /* The HUD extends beyond the world's last viewport. Present the complete
    Android surface, including hearts/counters, rather than cropping to it. */
 if(w==width&&h==height)return;
 if(w<160||h<160||w>width||h>height)return;
 Copy *copy=NULL;for(int i=0;i<16;i++)if(copies[i].context==context){copy=copies+i;break;}
 if(!copy)for(int i=0;i<16;i++)if(!copies[i].context){copy=copies+i;copy->context=context;break;}
 if(!copy)return;
 if(!copy->fbo||copy->w!=w||copy->h!=h){
  finish();if(copy->fbo){delete_fbo(1,&copy->fbo);delete_rb(1,&copy->colour);}
  gen_fbo(1,&copy->fbo);gen_rb(1,&copy->colour);bind(0x8d40,copy->fbo);bind_rb(0x8d41,copy->colour);storage(0x8d41,0x8058,w,h);attach(0x8d40,0x8ce0,0x8d41,copy->colour);
  unsigned result=status(0x8d40);bind_rb(0x8d41,rb);bind(0x8ca9,draw);bind(0x8ca8,read);
  if(result!=0x8cd5){fprintf(stderr,"[fifa14/display] copy framebuffer incomplete=%#x\n",result);return;}
  copy->w=w;copy->h=h;fprintf(stderr,"[fifa14/display] complete content %dx%d -> physical %dx%d, viewport=%d,%d,%d,%d\n",w,h,width,height,viewport[0],viewport[1],viewport[2],viewport[3]);
 }
 unsigned char scissor=enabled(0xc11);disable(0xc11);
 /* Two non-overlapping blits; reading and writing the same default buffer
  * with overlapping rectangles is undefined. Preserve the game's bindings. */
 bind(0x8ca8,0);bind(0x8ca9,copy->fbo);blit(sx,sy,sx+w,sy+h,0,0,w,h,0x4000,0x2600);
 bind(0x8ca8,copy->fbo);bind(0x8ca9,0);
 int dw=width,dh=height,x=0,y=0;
 if(getenv("FIFA14_LETTERBOX")&&!getenv("FIFA14_PANEL_STRETCH")){
  dw=width;dh=(int)((int64_t)width*h/w);if(dh>height){dh=height;dw=(int)((int64_t)height*w/h);}
  x=(width-dw)/2;y=(height-dh)/2;
  static int logged_w,logged_h;if(logged_w!=w||logged_h!=h){fprintf(stderr,"[fifa14/display] centered source=%d,%d %dx%d destination=%d,%d %dx%d panel=%dx%d\n",sx,sy,w,h,x,y,dw,dh,width,height);logged_w=w;logged_h=h;}
  int old_mask[4];float old_colour[4];get(0xc23,old_mask);get_float(0xc22,old_colour);
  mask(1,1,1,1);clear_colour(0,0,0,1);clear(0x4000);
  clear_colour(old_colour[0],old_colour[1],old_colour[2],old_colour[3]);mask(old_mask[0],old_mask[1],old_mask[2],old_mask[3]);
 }
 blit(0,0,w,h,x,y,x+dw,y+dh,0x4000,0x2601);
 bind(0x8ca9,draw);bind(0x8ca8,read);if(scissor)enable(0xc11);
}
