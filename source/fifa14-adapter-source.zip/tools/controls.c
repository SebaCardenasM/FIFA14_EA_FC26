#define _GNU_SOURCE
#include <stdbool.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <dlfcn.h>
#include "so_util.h"
#include "jni.h"
#include "offsets.h"

static JNIEnv *je;static jobject ja;static so_module *module;static uintptr_t core;
static void ABI_ATTR(*pointer)(JNIEnv*,jobject,int,int,int,float,float);
static void ABI_ATTR(*back)(JNIEnv*,jobject);
static unsigned char(*button)(void*,int);static short(*axis)(void*,int);
static void(*show_cursor)(int,float,float);
static int down_id,move_id,up_id,cursor=1,held_l3,held_b,show_touch_buttons=1;
static float cx=320,cy=240;static struct timespec last;
typedef struct{int down;float x,y;} Contact;
static Contact contacts[10];
static uintptr_t lookup(const char*n){uintptr_t(*fn)(so_module*,const char*)=(void*)(core+HOST_symbol);return fn(module,n);}
static int native_id(const char*n){int ABI_ATTR(*fn)(JNIEnv*,jobject)=(void*)lookup(n);return fn?fn(je,ja):0;}
static void contact(int id,int pressed,float x,float y){
 if(!pointer||id<0||id>=10)return;Contact*c=contacts+id;
 if(pressed){if(!c->down)pointer(je,ja,down_id,1000,id,x,y);else if(id==0||x!=c->x||y!=c->y)pointer(je,ja,move_id,1000,id,x,y);}
 else if(c->down)pointer(je,ja,up_id,1000,id,c->x,c->y);
 if(pressed!=c->down)fprintf(stderr,"[fifa14/controls] contact=%d down=%d x=%.0f y=%.0f\n",id,pressed,x,y);
 c->down=pressed;c->x=x;c->y=y;
}
static void release_all(void){for(int i=0;i<10;i++)contact(i,0,contacts[i].x,contacts[i].y);}
static void change_mode(int enabled){if(cursor==enabled)return;release_all();cursor=enabled;fprintf(stderr,"[fifa14/controls] mode=%s\n",cursor?"menu cursor":"classic gamepad");}
void fifa14_controls_init(JNIEnv*e,jobject a,so_module*m,uintptr_t h,int initial_cursor){
 je=e;ja=a;module=m;core=h;cursor=initial_cursor;
 const char*touch=getenv("FIFA14_TOUCH_BUTTONS");show_touch_buttons=!touch||strcmp(touch,"0");
 fprintf(stderr,"[fifa14/controls] touchscreen graphics=%s\n",show_touch_buttons?"visible":"hidden; may present errors");
 pointer=(void*)lookup("Java_com_ea_blast_TouchSurfaceAndroid_NativeOnPointerEvent");
 back=(void*)lookup("Java_com_ea_blast_MainActivity_NativeOnBackPressed");
 down_id=native_id("Java_com_ea_blast_TouchSurfaceAndroid_NativeGetIdRawPointerDown");
 move_id=native_id("Java_com_ea_blast_TouchSurfaceAndroid_NativeGetIdRawPointerMove");
 up_id=native_id("Java_com_ea_blast_TouchSurfaceAndroid_NativeGetIdRawPointerUp");
 button=dlsym(RTLD_DEFAULT,"SDL_GameControllerGetButton");axis=dlsym(RTLD_DEFAULT,"SDL_GameControllerGetAxis");show_cursor=dlsym(RTLD_DEFAULT,"fifa14_cursor_state");
 /* Bypass the old SDL cursor filter; input ownership is exclusively here. */
 void*sdl=dlopen("libSDL2-2.0.so.0",RTLD_NOW|RTLD_NOLOAD);if(sdl){button=dlsym(sdl,"SDL_GameControllerGetButton");axis=dlsym(sdl,"SDL_GameControllerGetAxis");}
 clock_gettime(CLOCK_MONOTONIC,&last);
 fprintf(stderr,"[fifa14/controls] classic layout 640x480; physical A pass/switch, B shoot/slide, X through/call, Y sprint/tackle, L1 call, R1 sprint; L3 cursor, R3 FPS\n");
}
void fifa14_controls_tick(void*pad){
 if(!je)return;
 /* Native 1.3.6 draw-only flags; input hit regions stay active. */
 volatile int*hide_pad=(void*)(module->text_base+0x1181c00);
 volatile int*hide_buttons=(void*)(module->text_base+0x1181c04);
 int hidden=!show_touch_buttons;
 if(*hide_pad!=hidden)*hide_pad=hidden;if(*hide_buttons!=hidden)*hide_buttons=hidden;
 /* The original match initializer also disables the pad's input state when
    DISABLE_PAD_RENDERING is set. Restore its normal initial enabled state
    once per HUD instance, while retaining the draw-only global flag. */
 static uintptr_t restored_hud;uintptr_t hud=*(uintptr_t*)(module->text_base+0x1181938);
 if(hidden&&hud&&hud!=restored_hud){volatile unsigned char*active=(void*)(hud+0xc788);unsigned before=*active;if(before<=1){*active=1;restored_hud=hud;fprintf(stderr,"[fifa14/stick] restored initial pad input state %u->1, HUD=%p\n",before,(void*)hud);}}
 struct timespec now;clock_gettime(CLOCK_MONOTONIC,&now);float dt=(now.tv_sec-last.tv_sec)+(now.tv_nsec-last.tv_nsec)/1e9f;last=now;if(dt>.05f)dt=.05f;
 if(pad&&button){
  unsigned char s[15];for(int i=0;i<15;i++)s[i]=button(pad,i);
  if(s[7]&&!held_l3)change_mode(!cursor);held_l3=s[7];
  float x=0,y=0;if(axis){short ax=axis(pad,0),ay=axis(pad,1);if(abs(ax)>6500)x=ax/32767.f;if(abs(ay)>6500)y=ay/32767.f;}
  x+=s[14]-s[13];y+=s[12]-s[11];float length=__builtin_sqrtf(x*x+y*y);if(length>1){x/=length;y/=length;}
  if(cursor){
   cx+=x*260*dt;cy+=y*260*dt;if(cx<1)cx=1;if(cx>638)cx=638;if(cy<1)cy=1;if(cy>478)cy=478;
   contact(0,s[1],cx,cy);
   if(s[0]&&!held_b&&back)back(je,ja);
  }else{
   /* The game uses a floating joystick. Anchor DOWN at its centre before
      moving the same contact, so every direction begins at neutral. */
   int moving=x!=0||y!=0;if(moving&&!contacts[0].down)contact(0,1,100,377);
   contact(0,moving,100+x*48,377+y*48);
   contact(2,s[1],515,444);  /* PASS / SWITCH */
   contact(3,s[0],605,356);  /* SHOOT / SLIDE */
   contact(4,s[3]||s[9],533,371); /* THROUGH / CALL 2nd DEF */
   contact(5,s[2]||s[10],591,435); /* SPRINT / TACKLE */
  }
  contact(6,s[6]&&!s[4],616,18); /* Pause; exit chord belongs to launcher. */
  held_b=s[0];
 }
 FILE*f=fopen("controls.req","r");if(f){char kind[24];int a=0,b=0;if(fscanf(f,"%23s %d %d",kind,&a,&b)>=2){if(!strcmp(kind,"cursor"))change_mode(a!=0);else if(!strcmp(kind,"tap")&&pointer){contact(8,1,a,b);contact(8,0,a,b);}}fclose(f);unlink("controls.req");}
 if(show_cursor)show_cursor(cursor,cx,cy);
}
