from pathlib import Path
import sys,time,shlex,json,hashlib
R=Path(__file__).resolve().parents[1];C=R/'candidate';remote='/roms/ports/fifa14'
sys.path.insert(0,str(R.parent/'Blasphemous_ArkOS/tools'))
from current_card_connection import connect

def execute(c,command,timeout=20):
 _,o,e=c.exec_command(command,timeout=timeout);out=o.read().decode(errors='replace');err=e.read().decode(errors='replace');code=o.channel.recv_exit_status();print(out+err);assert code==0,(code,command);return out

with connect() as c:
 if sys.argv[1] in ['update','persist']:
  if sys.argv[1]=='update':
   execute(c,'! pgrep -f "(^|/| )(unity6-gles3|unity-native-loader|gmloadernext.aarch64|evoland2-host|fifa14-host)( |$)" >/dev/null')
  else:
   # Atomic rename leaves the active mapping/inode intact. Only these
   # next-launch files may change while the process is running.
   assert all(n in {'libfifa14.so','runtime.sha256','README.txt','verify-runtime.py','source/fifa14-adapter-source.zip'} or n.startswith('license/libraries/') and '..' not in n for n in sys.argv[2:])
   execute(c,'p=$(cat $(cat '+remote+'/latest-report)/game.pid); test "$(readlink /proc/$p/cwd)" = '+remote)
  names=sys.argv[2:]
  if not names:
   with c.open_sftp() as s:old_manifest=s.open(remote+'/runtime.sha256').read().decode()
   old={line.split(None,1)[1].strip():line.split(None,1)[0] for line in old_manifest.splitlines() if line.strip()}
   current={line.split(None,1)[1].strip():line.split(None,1)[0] for line in (C/'runtime.sha256').read_text().splitlines() if line.strip()}
   names=[n for n,digest in current.items() if old.get(n)!=digest]+['runtime.sha256']
  stamp=time.strftime('%Y%m%d-%H%M%S');rev=remote+'/revisions/'+stamp
  execute(c,'mkdir -p '+rev)
  with c.open_sftp() as s:
   for n in names:
    path=remote+'/'+n
    execute(c,'mkdir -p '+shlex.quote(str(Path(path).parent).replace('\\','/'))+' '+shlex.quote(str(Path(rev+'/'+n).parent).replace('\\','/')))
    execute(c,'test ! -f '+shlex.quote(path)+' || cp -p -- '+shlex.quote(path)+' '+shlex.quote(rev+'/'+n))
    s.put(str(C/n),path+'.updating');s.posix_rename(path+'.updating',path)
  execute(c,'cd '+remote+' && python3 verify-runtime.py >reports/update-integrity.log && echo ALL_CURRENT_HASHES_OK',180)
  script="from pathlib import Path;import json,hashlib;r=Path("+repr(remote)+");cache=json.loads((r/'.runtime-verified.json').read_text());(r/'.runtime-offline-verified.json').write_text(json.dumps({'schema':1,'runtime_manifest_sha256':hashlib.sha256((r/'runtime.sha256').read_bytes()).hexdigest(),'files':{n:[v[0],v[1],v[2]] for n,v in cache.items()}}))"
  execute(c,'python3 -c '+shlex.quote(script))
 elif sys.argv[1]=='start':
  execute(c,'! pgrep -f "(^|/| )(unity6-gles3|unity-native-loader|gmloadernext.aarch64|evoland2-host|fifa14-host)( |$)" >/dev/null')
  execute(c,'rm -f -- '+remote+'/quit.req '+remote+'/capture.req '+remote+'/controls.req '+remote+'/input.req')
  unit='fifa14-test-'+time.strftime('%H%M%S')
  execute(c,'sudo -n systemd-run --collect --uid=ark --gid=ark --unit='+unit+' --setenv=FIFA14_TEST_DETACHED=1 /bin/bash '+remote+'/launch.sh')
 elif sys.argv[1]=='status':
  with c.open_sftp() as s:report=s.open(remote+'/latest-report').read().decode().strip()
  execute(c,'tail -n 55 '+report+'/game.log; tail -n 8 '+report+'/launcher.log; test ! -f '+report+'/exit-code || cat '+report+'/exit-code')
  with c.open_sftp() as s:
   for n in ['game.log','launcher.log','memory.log','environment.sh']:
    try:s.get(report+'/'+n,str(R/'reports'/n))
    except FileNotFoundError:pass
 elif sys.argv[1] in ['tap','key','cursor','quit']:
  with c.open_sftp() as s:
   with s.open(remote+('/quit.req' if sys.argv[1]=='quit' else '/controls.req')+'.preparing','w') as f:f.write(' '.join(sys.argv[1:])+'\n')
   s.posix_rename(remote+('/quit.req' if sys.argv[1]=='quit' else '/controls.req')+'.preparing',remote+('/quit.req' if sys.argv[1]=='quit' else '/controls.req'))
 elif sys.argv[1]=='capture':
  with c.open_sftp() as s:
   try:before=s.stat(remote+'/capture.ppm').st_mtime
   except FileNotFoundError:before=0
   with s.open(remote+'/capture.req','w') as f:f.write('capture\n')
   fresh=False
   for _ in range(30):
    time.sleep(.2)
    try:
     if s.stat(remote+'/capture.ppm').st_mtime>before:fresh=True;break
    except FileNotFoundError:pass
   if not fresh:print('Capture pending: the renderer has not produced a new capture.');sys.exit(0)
   p=R/'reports'/('capture-'+time.strftime('%H%M%S')+'.ppm');s.get(remote+'/capture.ppm',str(p))
  from PIL import Image
  with Image.open(p) as im:im.save(p.with_suffix('.png'))
  print(p.with_suffix('.png'))
