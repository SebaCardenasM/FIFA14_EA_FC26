#define _GNU_SOURCE
#include <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdint.h>
#include <string.h>
#include <time.h>
void *fifa14_native_open(const char*p,int f){return dlopen(p,f);}
void fifa14_set_content_size(int,int);
void fifa14_fullscreen_present(int,int);
static void *window;
static void *cursor_pad;
static int cursor_on,cursor_held;
static float cursor_x=320,cursor_y=240;
unsigned long fifa14_present_serial;
void fifa14_cursor_state(int on,float x,float y){cursor_on=on;cursor_x=x;cursor_y=y;}
static unsigned char(*raw_button)(void*,int);
static short(*raw_axis)(void*,int);
static void requested_exit(const char *reason){
 extern void dt_input_set_quit(void);
 fprintf(stderr,"[fifa14/exit] %s; requesting NativeActivity pause/stop\n",reason);
 dt_input_set_quit();
}
static void cursor_controller(void){
 if(!raw_button)raw_button=dlsym(RTLD_NEXT,"SDL_GameControllerGetButton");
 if(!raw_axis)raw_axis=dlsym(RTLD_NEXT,"SDL_GameControllerGetAxis");
 if(!cursor_pad){void*(*open)(int)=dlsym(RTLD_NEXT,"SDL_GameControllerOpen");if(open)cursor_pad=open(0);}
}
unsigned char SDL_GameControllerGetButton(void *pad,int id){cursor_controller();return cursor_on?0:(raw_button?raw_button(pad,id):0);}
unsigned SDL_GetMouseState(int*x,int*y){
 cursor_controller();int toggle=cursor_pad&&raw_button&&raw_button(cursor_pad,4)&&raw_button(cursor_pad,10);
 if(toggle&&!cursor_held){cursor_on=!cursor_on;fprintf(stderr,"[fifa14/input] SELECT+R1 cursor=%d; physical A clicks\n",cursor_on);}cursor_held=toggle;
 if(!cursor_on){unsigned(*f)(int*,int*)=dlsym(RTLD_NEXT,"SDL_GetMouseState");return f?f(x,y):0;}
 static double last;struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);double now=t.tv_sec+t.tv_nsec/1e9,dt=now-last;last=now;if(dt>.05)dt=.05;
 float dx=0,dy=0;
 if(cursor_pad&&raw_axis){short ax=raw_axis(cursor_pad,0),ay=raw_axis(cursor_pad,1);if(abs(ax)>6500)dx=ax/32767.f;if(abs(ay)>6500)dy=ay/32767.f;}
 if(cursor_pad&&raw_button){dx+=raw_button(cursor_pad,14)-raw_button(cursor_pad,13);dy+=raw_button(cursor_pad,12)-raw_button(cursor_pad,11);}
 cursor_x+=dx*300*dt;cursor_y+=dy*300*dt;if(cursor_x<1)cursor_x=1;if(cursor_x>638)cursor_x=638;if(cursor_y<1)cursor_y=1;if(cursor_y>478)cursor_y=478;
 if(x)*x=(int)cursor_x;if(y)*y=(int)cursor_y;return cursor_pad&&raw_button&&raw_button(cursor_pad,1)?1:0;
}
int SDL_PollEvent(void *event){
 static int(*poll)(void*);if(!poll)poll=dlsym(RTLD_NEXT,"SDL_PollEvent");
 if(poll&&poll(event)){if(event&&*(unsigned*)event==0x100)requested_exit("SDL_QUIT");return 1;}
 if(event&&!access("quit.req",F_OK)){unlink("quit.req");requested_exit("quit.req");}
 if(!event)return 0;cursor_controller();if(!cursor_pad||!raw_button)return 0;
 int exiting=raw_button(cursor_pad,4)&&raw_button(cursor_pad,6);
 if(exiting)requested_exit("SELECT+START");
 return 0;
}
static void draw_cursor(int w,int h){
 if(!cursor_on)return;
 void*(*proc)(const char*)=dlsym(RTLD_NEXT,"SDL_GL_GetProcAddress");if(!proc)return;
 void(*get)(unsigned,int*)=proc("glGetIntegerv"),(*getf)(unsigned,float*)=proc("glGetFloatv"),(*enable)(unsigned)=proc("glEnable"),(*disable)(unsigned)=proc("glDisable"),(*scissor)(int,int,int,int)=proc("glScissor"),(*colour)(float,float,float,float)=proc("glClearColor"),(*clear)(unsigned)=proc("glClear");unsigned char(*enabled)(unsigned)=proc("glIsEnabled");
 if(!get||!getf||!enable||!disable||!scissor||!colour||!clear||!enabled)return;
 int s[4];float c[4];get(0xc10,s);getf(0xc22,c);int had=enabled(0xc11);enable(0xc11);
 int dw=w,dh=w*3/4;if(dh>h){dh=h;dw=h*4/3;}int px=(w-dw)/2+(int)(cursor_x*dw/640),py=(h-dh)/2+dh-(int)(cursor_y*dh/480);
 colour(0,0,0,1);scissor(px-7,py-2,15,5);clear(0x4000);scissor(px-2,py-7,5,15);clear(0x4000);
 colour(0,1,1,1);scissor(px-6,py,13,1);clear(0x4000);scissor(px,py-6,1,13);clear(0x4000);
 colour(c[0],c[1],c[2],c[3]);scissor(s[0],s[1],s[2],s[3]);if(!had)disable(0xc11);
}
int SDL_GL_SetAttribute(int attr,int value){static int(*fn)(int,int);if(!fn)fn=dlsym(RTLD_NEXT,"SDL_GL_SetAttribute");if(attr==17&&value==2)value=3;return fn?fn(attr,value):-1;}
void *SDL_CreateWindow(const char*t,int x,int y,int w,int h,unsigned flags){static void*(*fn)(const char*,int,int,int,int,unsigned);if(!fn)fn=dlsym(RTLD_NEXT,"SDL_CreateWindow");window=fn?fn(t,x,y,w,h,flags):NULL;fifa14_set_content_size(640,480);return window;}
void SDL_GetWindowSize(void *win,int*w,int*h){if(w)*w=640;if(h)*h=480;}
static void capture(int w,int h){
 if(access("capture.req",F_OK))return;unlink("capture.req");
 void*(*proc)(const char*)=dlsym(RTLD_NEXT,"SDL_GL_GetProcAddress");if(!proc)return;
 void(*read)(int,int,int,int,unsigned,unsigned,void*)=proc("glReadPixels");if(!read)return;
 size_t count=(size_t)w*h;unsigned char *pixels=malloc(count*4),*rgb=malloc(count*3);if(!pixels||!rgb){free(pixels);free(rgb);return;}
 read(0,0,w,h,0x1908,0x1401,pixels);
 for(int y=0;y<h;y++)for(int x=0;x<w;x++){size_t src=((size_t)(h-y-1)*w+x)*4,dst=((size_t)y*w+x)*3;rgb[dst]=pixels[src];rgb[dst+1]=pixels[src+1];rgb[dst+2]=pixels[src+2];}
 FILE*f=fopen("capture.ppm.preparing","wb");if(f){fprintf(f,"P6\n%d %d\n255\n",w,h);int ok=fwrite(rgb,3,count,f)==count;int closed=fclose(f)==0;if(ok&&closed)rename("capture.ppm.preparing","capture.ppm");}free(pixels);free(rgb);
}
void SDL_GL_SwapWindow(void *win){
 static void(*swap)(void*),(*size)(void*,int*,int*);static void*(*open)(int);static unsigned char(*button)(void*,int);static void*pad;static int held;
 if(!swap){swap=dlsym(RTLD_NEXT,"SDL_GL_SwapWindow");size=dlsym(RTLD_NEXT,"SDL_GL_GetDrawableSize");open=dlsym(RTLD_NEXT,"SDL_GameControllerOpen");button=dlsym(RTLD_NEXT,"SDL_GameControllerGetButton");}
 if(!pad&&open)pad=open(0);
 int pressed=pad&&button&&button(pad,8);
 if(pressed&&!held){const char *old=getenv("PORT_FPS_HUD");int visible=!old||!strcmp(old,"0");setenv("PORT_FPS_HUD",visible?"1":"0",1);fprintf(stderr,"[fifa14/fps] R3 overlay=%d (session only)\n",visible);}held=pressed;
 extern void portfps_present_begin(int,int),portfps_present_end(int);
 int w=0,h=0;if(size)size(win,&w,&h);if(w>0&&h>0){fifa14_fullscreen_present(w,h);draw_cursor(w,h);portfps_present_begin(w,h);capture(w,h);}if(swap){swap(win);fifa14_present_serial++;}if(w>0&&h>0)portfps_present_end(swap!=NULL);
}
