#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
void fifa14_speech_tick(uintptr_t);
__attribute__((constructor))static void verify_current_engine(void){
 uintptr_t base=0;FILE*f=fopen("reports/speech-test-base.txt","r");if(!f)return;
 fscanf(f,"%x",&base);fclose(f);
 if(!base||*(uint32_t*)(base+0x49eadc)!=0xe92d48f0u)return;
 unsigned char*(*get)(void)=(void*)(base+0x63f544);unsigned char*p=get();if(!p)return;
 float progress=*(float*)(p+0x35a0);int selected=*(int*)(p+0x35a4),installed=*(int*)(p+0x35a8);unsigned char muted=p[0x359c];
 *(int*)(p+0x35a8)=-1;
 fifa14_speech_tick(base);
 int ok=*(int*)(p+0x35a8)==selected&&*(float*)(p+0x35a0)==100.0f&&!p[0x359c];
 /* Do not change the active match's settings while auditing the helper. */
 *(float*)(p+0x35a0)=progress;*(int*)(p+0x35a8)=installed;p[0x359c]=muted;
 f=fopen("reports/speech-registration-selftest.txt","w");if(f){fprintf(f,"%s: actual 1.3.6 profile, local bank sizes, registration and restoration\n",ok?"PASS":"FAIL");fclose(f);}
}
