# FIFA 14 / EA FC MOD 26 BY ZEOL - revision 2026-10-26

Base Android 1.3.6 (136), EA/RenderWare GLES2 ARM32. Host: EapRules/masseffect-native-arm v1.0.7, commit aab222fb38b44e5285483911b787712aade6e1b3. Its original main is replaced; Mass Effect-specific offsets are not executed.

All supplied game resources were installed on microSD, with SD1/SD2 relative launcher and bundled ARM32 libraries for the validated RK3326 kernel 4.4 profile. Other hardware/firmware combinations remain untested.

The 2.15GB donor EB OBB was compacted to 1,568,302,198 bytes; all 1217 selected resources were independently read back. Overrides from the supplied data were merged. Main SPA_ES.loc from loose data was Portuguese, so actual archive Spanish was preserved. Donor profiles, saves, phone shaders, logs, FUT personal cache and duplicate downloads were excluded. Speech and roster content are included in full.

Five original menu XML resources restore Career under Play and controls/display/audio under Customize. The donor moved settings under Play and emptied Customize. Both corrected menus were captured and checked.

Bionic statfs layout and UTF16 libc bridges fix false free-space errors and a prior Career initialization crash. Old Career resume with the new database still crashed at game+0x9da794. Creating a new career reached team selection, sponsorship, friendly selection and initial simulation. Observed matches after that include Barcelona/Athletic and Barcelona/Real Madrid; do not claim every match belonged to Career. Old saves are backed up on SD.

Speech files initially existed but Profile installed-locale was -1. Local registration made the UI show Spanish; commentary was enabled through the actual sound menu. The game then opened Speech/dat_ENG_US.big during a match. The user replied positively and requested the ZIP, but did not separately confirm the spoken language. speech.c registers the verified local bank for unregistered profiles using the native completion fields (callback game+0x49eadc): float progress100 at +0x35a0, selected/installed locale at +0x35a4/+0x35a8, mute0 at +0x359c. Existing installed profiles retain their own mute setting.

Presentation: centered 640x480 4:3. Menu cursor retained. Physical gameplay translation uses floating stick contact0 and separate action contacts. Hidden pad initializer's input flag is restored. L3 cursor/gamepad, R3 measured FPS toggle, immediate Select+Start exit. Match logs generally show ~30FPS with dips during loads/transitions; no universal 30FPS guarantee.

Known unresolved crash: changing Display options during a match produced a null structure at game+0xcd2c2c. No blind null-suppression patch was applied. Full seasons, all touch gestures and manual Ports launch of this revision still need testing. Last observed match exited through NativeOnPause/Stop with exit0.

Full package includes game data, native engine, private runtime, graphics library, Speech, roster, launcher, source and licenses. It does not include personal saves. The current distributed launcher creates no automatic save backups; existing development backups remain separate from the delivery.

Detailed provenance and hashes: reports/content-update-plan.json, menu-correction.json, last-content-install.json and package-final.json.

## Touchscreen selector — 30/10/2026

The branded startup screen now offers with/without touchscreen buttons.
With buttons is the initial selection on every launch. The without option
shows SIN TACTILES PUEDE PRESENTAR ERRORES. D-pad/joystick changes the
selection; A/B/START confirms and SELECT cancels back to the frontend.
The intro atomically writes a per-run 0/1 choice file; the launcher validates
it and exports FIFA14_TOUCH_BUTTONS. controls.c applies both native draw
flags accordingly, preserving physical-to-touch translation. The hidden-pad
input initializer workaround is limited to the hidden mode. Userdata is preserved.
Both choices were rendered with the native ARM32 binary in SDL software
preview and checked for readable text and margins. Real handoff verification
is recorded in reports/touch-selector-install.json when available.
